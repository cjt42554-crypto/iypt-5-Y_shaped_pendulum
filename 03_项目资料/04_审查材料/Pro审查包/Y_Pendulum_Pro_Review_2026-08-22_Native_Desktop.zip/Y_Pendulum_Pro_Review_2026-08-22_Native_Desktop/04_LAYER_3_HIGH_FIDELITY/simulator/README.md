# Y-Pendulum 独立高保真模拟与统一研究平台

> **默认用户入口是完全本地的原生 Tk 桌面应用：`ypendulum ui`。**它不启动浏览器或 HTTP 服务，可在断网状态下使用。界面、启动命令、运行方式、控制、视图和限制见 [原生本地桌面平台说明](docs/NATIVE_DESKTOP_GUI.md)。历史 Streamlit 原型仅保留为 `ypendulum ui-web` 开发备份。

本目录是 IYPT 2027 第五题 Y 形摆四层研究框架的**第 3 层程序**。当前规范高保真模型为：

```text
HF-DISCRETE-ROD-RIGID-BOB-1.0
```

它使用局部材料珠、被动的单边/双边轴向 Kelvin–Voigt 混合律、非零三点中心线弯曲、有限球形刚体摆球、四元数姿态、偏心材料连接和有限尺寸接触守卫。正式 HF 计算取双边离散杆极限，因而另行输出可正可负的有符号轴力与非负张力；只有受控极限研究才把压缩正则逐步关闭。它不导入冻结前向柔索方程的状态推进器或离散弱形式。

旧 `full`/H1 轴向 cable/truss 路径仍保留，用于历史示例和兼容测试；它不是本阶段的独立高保真交付，不得再被当作 HF 证据。

完整理论与实现合同见：

- [阶段 3 独立理论与程序说明](../IYPT_2027_Y_Pendulum_第一性原理高保真模拟理论与程序说明.md)
- [本包理论摘要](docs/theory.md)
- [数值方法摘要](docs/numerical_method.md)
- [限制与停止规则](docs/limitations.md)

## 当前科学状态

- 软件定位：个人科研计算工具/可修改原型，不是对外发布或生产系统。
- 最低验收：方程与本层理论一致，目标配置能跑，状态/有符号轴力/张力/能量/守卫可输出，代表性网格和时间步敏感性足够，明显的数值、接触或事件错误不能伪装成成功。
- 数值声明上限：`VERIFIED`。
- 真实实验：尚未冻结，因此不能宣称 `VALIDATED` 或 `PREDICTIVE`。
- 结构性理论：不属于本目录；必须在阶段 3 正式证据冻结后另文研究。
- 历史 manifest、ZIP、wheel/sdist 不作为本个人工具的科学验收前置条件；已经存在的身份信息保留，但不再为发布目的扩张。

## 模型与程序层次

| 身份/路径 | 内容 | 当前用途 |
|---|---|---|
| `HF-DISCRETE-ROD-RIGID-BOB-1.0` | 材料珠、被动轴向混合律、三点弯曲、有限偏心刚体摆球 | 阶段 3 规范 HF；正式算例为双边杆端点 |
| 冻结 `FWD-CABLE-1.0`（外部目录） | 阶段 2 前向数值后端 | 只读外部比较后端 |
| `full` / H1 legacy | 轴向 cable/truss 有限元、质心点摆球 | 历史回归与兼容，不作为独立 HF |
| A0/A1 legacy | 解析小振幅/理想环面 | 历史基准，不属于本阶段主求解器 |

## 安装

要求 Python 3.11 或更高：

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e '.[ui,dev]'
```

全部内部规范量使用 SI。配置检查主要用来防止单位、网格或时间步误写导致昂贵的无效求解，不把恶意输入防御当作本项目主任务。

## 独立 HF 单次运行

```bash
ypendulum validate-config configs/examples/high_fidelity_shared_forward_window.yaml
YPS_HF_POSTPROCESS_WORKERS=12 \
ypendulum simulate configs/examples/high_fidelity_shared_forward_window.yaml
```

生产配置使用与冻结前向算例相同的支点、质量、自然长度、线密度、轴向 (EA/C_a)、空气参数、结点/质心初态和 0.12 s 时间窗；直径、弯曲、刚体半径/惯量/偏心连接和接触守卫是 HF 专属输入。

原始 HF 求解器在没有连续守卫复核时保守地返回 `UNDETERMINED / SUCCESS_SINGLE_RUN_GUARDS_UNCERTIFIED`；这不代表求解失败，而是不把只检查离散样本写成“已排除所有相切越界”。对实际目标算例，可用已有的独立守卫复核将这一状态升级；不要为了得到一个“成功”字符串而删除守卫。

个人研究模式可直接对这个原始结果运行 `analyze`、`compare` 和
`compare-experiment`；报告会保留上述原始状态，不会伪装成完整认证。只有显式
传入 `--hf-validation-spec` 时才运行可选的严格证书流程。

## 可选的严格数值资格矩阵

```bash
ypendulum hf-validate \
  configs/examples/high_fidelity_shared_forward_window.yaml \
  configs/high_fidelity_shared_forward_validation.yaml \
  --output /tmp/yps-hf-validation-fresh
```

该命令保留给需要完整六候选矩阵时使用，但它不再是个人目标算例的发布级前置条件。它运行：

- 目标最细网格的 (N/4\to N/2\to N) 空间研究；
- 容差/最大步的三层时间研究；
- Radau/BDF 两算法交叉；
- 26 个完整状态/派生量的 Cauchy 比较（含有符号轴力与非负张力）；
- 独立功—能重算；
- 接受步 Hermite–Simpson 动力学缺陷；
- 状态、拓扑、守卫、耗散、四元数和身份门。

`HF_REFINEMENT_SUPPORTED` 只表示该冻结配置获得数值加密支持，不表示真实实验验证。

## HF 物理独立性研究

```bash
ypendulum hf-independence \
  configs/examples/high_fidelity_independence_torque.yaml \
  configs/high_fidelity_shared_forward_validation.yaml \
  configs/high_fidelity_independence_validation.yaml \
  --output /tmp/yps-hf-independence-fresh
```

该研究同步缩小弯曲刚度、偏心连接半径和有限摆球排除半径，同时保持质量、重力、轴向材料律、初态、网格和数值合同不变。它要求极限层收缩，并要求完整 HF 与极限之间的差异显著大于 Radau/BDF 数值差异。

## 统一双后端平台

严格共享输入审计：

```bash
ypendulum unified-audit configs/unified_shared_forward_case.yaml
```

同一输入串行运行冻结前向后端和独立 HF 后端：

```bash
ypendulum unified-run configs/unified_shared_forward_case.yaml \
  --backend both \
  --output /tmp/yps-unified-fresh
```

比较结果只量化公共输出的模型差异，不自动给出模型优劣或结构性结论。实验接口只接受严格米制 `time_s,x_m,y_m`；没有相机标定时，像素不会被当作米。

## 本地统一界面

```bash
ypendulum ui
```

界面支持：

- 严格 case 导入、共享输入审计和导出；
- 仅前向、仅 HF 或双后端；
- 重复运行、批量 case/参数扫描；
- 串行作业队列；
- 暂停、继续、停止和日志；
- 三维轨迹、HF 材料杆/刚体快照、张力、能量和后端差值；
- 米制实验轨迹的无拟合三方比较。

GUI 只调用统一适配器，不复制物理方程。

## 关键输出

HF 运行目录至少包含：

```text
config_source.yaml
config_original.yaml
config_resolved.yaml
provenance.json
result.h5
summary.json
diagnostics.json
events.csv
events.json
observer_output.npz
observer_summary.json
report.md
```

`result.h5` 保存展示网格、接受步完整状态、材料珠、结点、摆球质心/姿态/角速度/连接点、全杆路径、有符号轴力、非负张力、反力、能量和有效域守卫。物理数据集带单位与说明属性。

## 计算性能

- Radau/BDF 是隐式时间推进，后一步依赖前一步；主积分不伪造时间并行。
- 每个展示样本只计算一次局部力、接触、守卫和能量；静态拓扑、线段对和材料 socket 在建模时预计算。
- 展示样本按固定连续索引块用安全的 `spawn` 多进程并行，默认最多 12 个物理核心；事件排序和累计积分仍由主进程确定性完成。可用 `YPS_HF_POSTPROCESS_WORKERS=1|8|12|auto` 覆盖。
- 固定端点稳定性检查的有限差分 Hessian 列也可用 CPU 线程并行，线程数在运行诊断中记录。
- 网格、时间步、参数扫描和重复运行的成员互相独立，可以用多进程同时跑；单个成员的身份与输出目录仍分开。
- 积分结束、后处理开始前写入可回放 checkpoint；后处理失败或修改时无需重跑积分。CLI 使用 `--hf-checkpoint PATH` 与 `--resume-hf-checkpoint`。
- 当前没有 JAX/CuPy/Numba 后端。CPU 批处理已把完整 15,361 样本后处理从 191.07 s 降到 20.81 s；因此本版不冒险改写分支密集的隐式积分与 socket 守卫到 GPU，也不虚报桌面 GPU 占用。

同一 1 ms 代表算例的端到端墙钟由 113.75 s 降到 5.23 s（21.77×），
59 组科学数组全部通过、最大绝对差 `6.94e-18`。完整数字、CPU/GPU/内存和
复现命令见 [HF 性能优化与复现实测](docs/performance_optimization.md)。

个人研究所需的最小时间步/网格敏感性可用：

~~~bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 \
python scripts/run_representative_hf_sensitivity.py \
  --window-s 0.01 \
  --output validation/representative_hf_sensitivity.json \
  --series-output validation/representative_hf_sensitivity_series.npz
~~~

该脚本只制备一次目标细网格状态，然后以三个独立 CPU 进程并行计算
\(h\)、\(2h\) 和 20/20/30 网格；输出原始 RMS/最大差及逐守卫归一裕量。
它明确是代表性短窗研究，不冒充完整六候选资格矩阵。

## 测试

```bash
PYTHONDONTWRITEBYTECODE=1 pytest -q
```

本个人研究版以当前目标配置实跑、核心物理回归和代表性敏感性表为主要证据。旧测试日志不能替代当前源码的实跑，但不再要求 Git、wheel/sdist、ZIP 或复杂 manifest 互绑才允许做科学计算。

## 修改规则

本项目按研究程序而非发布产品维护：

1. 理论变化先明确新旧方程和适用域；
2. 改动局部 HF 模块与对应测试；
3. 若状态、力或守卫语义改变，必须升级 `model_id`；
4. 重新冻结配置和阈值；
5. 串行重跑独立性、收敛与统一比较；
6. 不用旧运行产物证明新源码。

## 明确排除

当前 HF 不含材料 director/扭转、非球形惯量、结点转动、接触后动力学、摩擦/断裂、滑动结、柔性支架双向耦合、完整 CFD、地面/笔尖/漏沙/颗粒。到达接触边界时返回 `OUT_OF_SCOPE`，不会在缺少物理闭合时继续穿透。
