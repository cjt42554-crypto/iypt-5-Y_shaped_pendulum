# YP-FPSim run report: desktop_quick_shared

- Model: `HF-DISCRETE-ROD-RIGID-BOB-1.0`
- Scientific claim: `VERIFIED`
- Status: `undetermined`
- Simulated duration: `0.0002` s

## Principal outputs

- frequency_fast_hz: `nan`
- frequency_slow_hz: `nan`
- frequency_ratio: `nan`
- phase_drift_rad_s: `nan`
- minimum_tension_N: `0.140454799126789`
- maximum_tension_N: `0.2568523390827199`
- max_abs_energy_balance_residual: `1.6819422547511497e-13`

## Numerical diagnostics

- model_id: `HF-DISCRETE-ROD-RIGID-BOB-1.0`
- physics_path: `local material beads + passive unilateral/bilateral KV blend + three-point bending + finite rigid bob`
- particle_count: `45`
- state_size: `283`
- junction_index: `44`
- bob_inertia_kg_m2: `1.279737148144409e-05`
- bob_attachment_body_m: `[-0.0, -0.0, -0.01999794636444272]`
- bob_contact_radius_m: `0.01999794636444272`
- physical_force_scale_N: `0.9382218188`
- tension_zero_tolerance_N: `2.1332694332159008e-13`
- axial_material_model: `passive_unilateral_bilateral_kelvin_voigt_blend`
- cable_material_field_semantics: `E, eta, area parameter source only; HF axial_material_model owns the constitutive branch`
- compression_regularization_scale: `1.0`
- geometry_singularity_floor_m: `3.26e-16`
- length_guard_m: `3.26e-13`
- bending_turn_clearance_floor: `1e-08`
- aerodynamic_chord_guard_m: `3.26e-15`
- quaternion_stabilization_rate_s_inv: `1.0`
- contact_registration_id: `FIXED_REST_MATERIAL_SOCKETS_PROJECTIVE_V2`
- same_branch_minimum_material_separation_m: `{'upper_A': 0.003232, 'upper_B': 0.003232, 'lower': 0.003232}`
- same_branch_full_contact_pair_count: `{'upper_A': 66, 'upper_B': 66, 'lower': 190}`
- same_branch_partial_contact_pair_count: `{'upper_A': 12, 'upper_B': 12, 'lower': 20}`
- junction_contact_pair_count: `3`
- contact_topology_precomputed: `True`
- bob_socket_rest_material_length_m: `0.02169794636444272`
- junction_pair_socket_rest_material_length_m: `{'upper_A__upper_B': 0.0064, 'upper_A__lower': 0.0064, 'upper_B__lower': 0.0064}`
- junction_socket_projective_opening_definition: `inf_{s,t>=0,s+t>0} ||p_i(s)-p_j(t)||^2/(s+t)^2 minus (required_center_separation/(2*socket_length))^2`
- branch_beads: `{'upper_A': 12, 'upper_B': 12, 'lower': 20}`
- branch_bending_stiffness_N_m2: `{'upper_A': 6.750000000000001e-06, 'upper_B': 6.750000000000001e-06, 'lower': 6.750000000000001e-06}`
- contact_scope: `bob-vs-rod and rod-vs-rod root guards; friction, compliant contact, fracture, ground contact and knot sliding excluded`
- runtime_seconds: `2.2949048090085853`
- integration_wall_seconds: `2.2949048090085853`
- integration_checkpoint_schema: `YPS-HF-INTEGRATION-CHECKPOINT-1.0`
- integration_checkpoint_path: `/tmp/yps-native-both-bimimk/output/.high_fidelity.integration-checkpoint.npz`
- integration_checkpoint_reused: `False`
- checkpoint_original_integration_wall_seconds: `2.2949048090085853`
- presentation_sample_evaluation_wall_seconds: `1.8501123830064898`
- postprocess_wall_seconds: `1.8505685650015948`
- postprocess_process_tree_cpu_seconds: `29.79000000000002`
- postprocess_average_equivalent_cpu_cores: `16.097755340383372`
- postprocess_average_cpu_utilization_percent: `1609.7755340383374`
- postprocess_worker_count: `12`
- postprocess_physical_core_count: `16`
- postprocess_parallel_backend: `DETERMINISTIC_FIXED_CONTIGUOUS_SPAWN_PROCESS_POOL_V1`
- solver_method: `Radau`
- rtol: `1e-08`
- position_atol_m: `1e-10`
- velocity_atol_m_s: `1e-09`
- quaternion_atol: `1e-10`
- angular_velocity_atol_rad_s: `1e-09`
- max_step_s: `1.25e-06`
- minimum_cell_wave_time_s: `0.0005154512586074459`
- jacobian_kind: `colored_finite_difference_from_local_HF_dependency_graph`
- jacobian_sparsity_nnz: `4264`
- nfev: `1125`
- njev: `2`
- nlu: `320`
- accepted_integration_step_count: `160`
- accepted_integration_step_hard_cap: `1024`
- resource_upper_bound: `{'estimate_id': 'HF_SINGLE_RUN_RESOURCE_HARD_CAP_V1', 'runtime_enforcement_id': 'MANUAL_SCIPY_RADAU_BDF_ACCEPTED_STEP_CAP_V1', 'total_elements': 44, 'state_size': 283, 'output_samples': 81, 'output_sample_limit': 2000001, 'nominal_accepted_steps': 161, 'accepted_step_budget': 1024, 'accepted_step_hard_cap': 1024, 'presentation_float_budget': 101088, 'accepted_trace_float_budget': 2897920, 'implicit_workspace_float_budget': 480534, 'serialized_result_float_budget': 672016, 'estimated_peak_memory_bytes': 34795420, 'peak_memory_limit_bytes': 8589934592, 'estimated_result_bytes': 6720160, 'result_limit_bytes': 8589934592, 'accepted_step_limit': 2000001}`
- resource_runtime_enforcement: `MANUAL_SCIPY_RADAU_BDF_ACCEPTED_STEP_CAP_V1`
- machine_scale_terminal_steps_coalesced: `0`
- terminal_time_coalescing_tolerance_s: `4.145611919760125e-14`
- minimum_accepted_integration_step_s: `1.2499999999995696e-06`
- maximum_accepted_integration_step_s: `1.2500000000000033e-06`
- preparation_force_residual_inf_N: `1.7550463122115926e-09`
- preparation_iterations: `3620`
- preparation_bob_held: `True`
- preparation_mode: `held_endpoint_bilateral_stable_equilibrium`
- preparation_audit: `{'protocol': 'HELD_ENDPOINT_STABLE_BILATERAL_EQUILIBRIUM_V1', 'fixed_dofs': ['junction_position', 'bob_com_position', 'bob_orientation', 'bob_attachment_position', 'support_A_position', 'support_B_position'], 'static_free_material_residual_inf_N': 1.7550463122115926e-09, 'static_fixture_reaction_force_world_N': {'support_A': [-0.0782376139944404, -0.0, -0.14488997041430834], 'support_B': [0.0782376139944404, -0.0, -0.14488997041430834], 'junction': [-0.024982431527996694, -0.014275675158855245, -0.0513619145402224], 'bob_com': [0.0249824189311927, 0.014275667960681733, -0.5672657938717742]}, 'static_fixture_reaction_torque_world_Nm': {'bob': [0.0002854840421943067, -0.0004995970738400301, -0.0]}, 'actual_release_free_material_net_force_inf_N': 1.7550463122115926e-09, 'actual_release_junction_net_force_world_N': [0.024982431527996694, 0.014275675158855245, 0.0513619145402224], 'actual_release_bob_net_force_world_N': [-0.0249824189311927, -0.014275667960681733, 0.5672657938717742], 'actual_release_bob_net_torque_world_Nm': [-0.0002854840421943067, 0.0004995970738400301, 0.0], 'minimum_hessian_eigenvalue_N_per_m': 0.35254749583498207, 'hessian_tolerance_N_per_m': 0.00014723926380368096, 'hessian_parallel_worker_count': 8, 'stability_class': 'PSD_STABLE_LOCAL_MINIMUM', 'seed_candidate_count': 3, 'selected_seed': 'gravity_plane', 'seed_geometry': {'upper_A': {'compressed_chord': False, 'gravity_seed_max_offset_m': 0.0, 'gravity_seed_direction_world': [0.0, 0.0, 0.0], 'out_of_plane_perturbation_max_m': 1.3909331898562592e-05}, 'upper_B': {'compressed_chord': False, 'gravity_seed_max_offset_m': 0.0, 'gravity_seed_direction_world': [0.0, 0.0, 0.0], 'out_of_plane_perturbation_max_m': 1.3909331898562592e-05}, 'lower': {'compressed_chord': False, 'gravity_seed_max_offset_m': 0.0, 'gravity_seed_direction_world': [0.0, 0.0, 0.0], 'out_of_plane_perturbation_max_m': 1.6099319951700753e-05}}, 'candidate_records': [{'seed': 'gravity_plane', 'iterations': 1206, 'energy_J': -0.021729026171809652, 'free_material_residual_inf_N': 1.7550463122115926e-09, 'minimum_hessian_eigenvalue_N_per_m': 0.35254749583498207, 'stability_audit_skipped_reason': None, 'escaped_negative_curvature': False, 'guards_valid': True, 'minimum_normalized_guard_margin': 0.0002141998749431784, 'optimizer_messages': ['STOP: TOTAL NO. OF ITERATIONS REACHED LIMIT', 'STOP: TOTAL NO. OF ITERATIONS REACHED LIMIT', 'STOP: TOTAL NO. OF ITERATIONS REACHED LIMIT', 'STOP: TOTAL NO. OF ITERATIONS REACHED LIMIT', 'STOP: TOTAL NO. OF ITERATIONS REACHED LIMIT', 'STOP: TOTAL NO. OF ITERATIONS REACHED LIMIT'], 'accepted_stable_candidate': True}, {'seed': 'gravity_plane_out_of_plane_plus', 'iterations': 1208, 'energy_J': -0.021729026171809676, 'free_material_residual_inf_N': 1.2829421840209257e-09, 'minimum_hessian_eigenvalue_N_per_m': None, 'stability_audit_skipped_reason': 'duplicate_of_existing_psd_stable_candidate', 'escaped_negative_curvature': False, 'guards_valid': True, 'minimum_normalized_guard_margin': 0.0002141998763805192, 'optimizer_messages': ['STOP: TOTAL NO. OF ITERATIONS REACHED LIMIT', 'STOP: TOTAL NO. OF ITERATIONS REACHED LIMIT', 'STOP: TOTAL NO. OF ITERATIONS REACHED LIMIT', 'STOP: TOTAL NO. OF ITERATIONS REACHED LIMIT', 'STOP: TOTAL NO. OF ITERATIONS REACHED LIMIT', 'STOP: TOTAL NO. OF ITERATIONS REACHED LIMIT'], 'accepted_stable_candidate': False}, {'seed': 'gravity_plane_out_of_plane_minus', 'iterations': 1206, 'energy_J': -0.021729026171809683, 'free_material_residual_inf_N': 8.562210342317501e-10, 'minimum_hessian_eigenvalue_N_per_m': None, 'stability_audit_skipped_reason': 'duplicate_of_existing_psd_stable_candidate', 'escaped_negative_curvature': False, 'guards_valid': True, 'minimum_normalized_guard_margin': 0.00021419987382606436, 'optimizer_messages': ['STOP: TOTAL NO. OF ITERATIONS REACHED LIMIT', 'STOP: TOTAL NO. OF ITERATIONS REACHED LIMIT', 'STOP: TOTAL NO. OF ITERATIONS REACHED LIMIT', 'STOP: TOTAL NO. OF ITERATIONS REACHED LIMIT', 'STOP: TOTAL NO. OF ITERATIONS REACHED LIMIT', 'STOP: TOTAL NO. OF ITERATIONS REACHED LIMIT'], 'accepted_stable_candidate': False}], 'gravity_continuation_steps': 6, 'negative_curvature_line_search_min_fraction': 1e-05, 'total_optimizer_iterations': 3620}`
- raw_guard_certification_status: `ACCEPTED_STEP_CONTINUOUS_CERTIFICATE_REQUIRED`
- energy_balance_scale_J: `0.3058603129288`
- energy_balance_scale_definition: `total_gravitational_force_scale_times_characteristic_length`
- max_abs_energy_balance_residual: `1.6819422547511497e-13`
- minimum_tension_N: `0.140454799126789`
- maximum_tension_N: `0.2568523390827199`
- minimum_signed_axial_force_N: `0.140454799126789`
- maximum_signed_axial_force_N: `0.2568523390827199`
- minimum_contact_margin_m: `0.00026982915923147617`
- minimum_bob_contact_margin_m: `0.020505498878833905`
- minimum_rod_self_contact_margin_m: `0.00026982915923147617`
- guard_component_metadata: `{'MINIMUM_SEGMENT_LENGTH': {'unit': 'm', 'scale': 0.326, 'tolerance': np.float64(7.412381819449365e-14)}, 'BENDING_TURN_CLEARANCE': {'unit': 'dimensionless', 'scale': 1.0, 'tolerance': np.float64(2.2737367544323206e-13)}, 'AERODYNAMIC_CHORD_LENGTH': {'unit': 'm', 'scale': 0.326, 'tolerance': np.float64(7.412381819449365e-14)}, 'BOB_ROD_CLEARANCE': {'unit': 'm', 'scale': 0.326, 'tolerance': np.float64(7.412381819449365e-14)}, 'ROD_SELF_CLEARANCE': {'unit': 'm', 'scale': 0.326, 'tolerance': np.float64(7.412381819449365e-14)}, 'BOB_SOCKET_MATERIAL_EXTENT': {'unit': 'm', 'scale': 0.326, 'tolerance': np.float64(7.412381819449365e-14)}, 'BOB_SOCKET_RADIAL_MONOTONICITY': {'unit': 'm^2', 'scale': 0.10627600000000001, 'tolerance': np.float64(2.4164364731404932e-14)}, 'BOB_SOCKET_CUT_CLEARANCE': {'unit': 'm', 'scale': 0.326, 'tolerance': np.float64(7.412381819449365e-14)}, 'JUNCTION_SOCKET_MATERIAL_EXTENT': {'unit': 'm', 'scale': 0.326, 'tolerance': np.float64(7.412381819449365e-14)}, 'JUNCTION_SOCKET_PROJECTIVE_OPENING': {'unit': 'dimensionless', 'scale': 1.0, 'tolerance': np.float64(2.2737367544323206e-13)}, 'JUNCTION_SOCKET_CUT_CLEARANCE': {'unit': 'm', 'scale': 0.326, 'tolerance': np.float64(7.412381819449365e-14)}}`
- minimum_segment_length_m: `0.008298582929057389`
- minimum_bending_turn_clearance: `1.9999594095246684`
- minimum_aerodynamic_chord_length_m: `0.02489832977880119`
- minimum_bob_socket_material_extent_m: `0.30430205363555723`
- minimum_bob_socket_radial_monotonicity_m2: `0.00016451878723961974`
- minimum_bob_socket_cut_clearance_m: `0.020305498878833907`
- minimum_junction_socket_material_extent_m: `0.2816`
- minimum_junction_socket_projective_opening: `0.25352829395124893`
- minimum_junction_socket_cut_clearance_m: `0.0039956984157118215`
- maximum_quaternion_norm_error: `6.661338147750939e-16`
- bending_energy_fraction_peak: `0.00016341788410276288`

## Interpretation boundary

This report verifies a numerical run. It is not experimental validation. `VALIDATED` or `PREDICTIVE` claims require an independent frozen validation manifest.
