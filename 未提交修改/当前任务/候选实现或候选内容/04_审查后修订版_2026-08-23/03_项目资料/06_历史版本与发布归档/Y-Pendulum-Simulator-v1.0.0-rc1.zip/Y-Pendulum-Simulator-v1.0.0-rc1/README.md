# YP-FPSim — Y-Pendulum 第一性原理高保真仿真器

YP-FPSim 是面向**固定材料结** Y-shaped pendulum 的可下载、可审计 Python 软件项目。高保真 H1 核心从三维线动量守恒、有限分布质量、重力、气动力和只受拉的轴向材料本构出发；它不把“三绳共面”“环面轨迹”“松绳”或“重新受拉”预先写入高保真运动方程。A0 解析模型和 A1 精确环面模型作为设计工具、快速基准和 H1 的理想极限检验保留。

## 发布状态

- 软件版本：`1.0.0rc1`（开发候选；最终发布门槛见 `CODEX_CONTINUATION_AND_ENVIRONMENT_GAPS.md`）
- 冻结执行规范：`docs/frozen_specification.md`
- 自动测试：`41 passed`，wheel、sdist 与完整 ZIP 解包路径均已复跑；
- 解析/半解析验证：V-001 至 V-013 全部执行，见 `validation/validation_report.md`
- 网格、时间精度和 Radau/BDF 对照：见 `validation/convergence_report.md`
- 发布安装与测试审计：见 `validation/release_audit.md`
- 实验验证：**尚未完成**。发布包没有封存实验数据，因此只能标记为 `DERIVED`/`VERIFIED`，不能宣称已经达到实验意义上的 `VALIDATED` 或 `PREDICTIVE`。

## 模型层级

| 模型 | 物理内容 | 主要用途 |
|---|---|---|
| A0 | 两个小振幅解析模态、频率比、闭合和漂移 | 装置设计与解析自检 |
| A1 | 无质量结点、无质量不可伸长绳、三绳正张力的精确环面 ODE | 有限振幅基准、快速扫描、张力失效边界 |
| H1 | 有限结点质量、有限绳质量、有限轴向刚度、单边张力和摆球平动 | 首版高保真核心 |
| H1-A | H1 加摆球与绳分布气动、浮力 | 包络和长期轨迹 |
| H1-P | H1 加固定或规定运动支点及支点做功 | 实测支点运动影响 |
| O1 | 相机投影、畸变、采样和曝光 | 与视频轨迹进行前向比较 |

H1 使用三维几何非线性 axial cable/truss 有限元。线性 Kelvin–Voigt 元素采用

\[
T=\begin{cases}
0,&\delta\le 0,\\
\max(0,k_e\delta+c_e\dot\delta),&\delta>0,
\end{cases}
\qquad
k_e=EA/L_e,
\qquad
c_e=\eta A/L_e.
\]

因此绳不会承担压缩力，松弛、自由飞行和重新受拉由本构与 Newton 方程自然产生。表格型张力—伸长本构按**整段绳标定长度**换算为各有限元的等效应变，保持网格客观性；详见 `docs/adr/ADR-0002-tabulated-material-mesh-objectivity.md`。

## 物理范围

v1.0 支持：三段材料绳固定在同一材料结点且互不滑动；任意三维固定或规定运动支点；有限结点质量；有限绳质量；线性 Kelvin–Voigt 或表格型只受拉本构；摆球质心平动；摆球和绳气动；浮力；自动松弛/重新受拉；支点反力与做功；相机前向模型；同参数消融；Monte Carlo 不确定度传播。

v1.0 不声称覆盖：连续上绳穿环滑动、结点摩擦滑移、绳自接触、显著弯曲/扭转刚度、偏心刚体摆球、地面碰撞、完整 CFD、Cosserat 杆、笔尖接触和漏沙质量流失。详见 `docs/limitations.md`。

## 安装

要求 Python 3.11 或更高。

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -e .
```

本地网页界面和开发工具是可选依赖：

```bash
python -m pip install -e '.[ui,dev]'
```

也可安装发布包中的 wheel：

```bash
python -m pip install dist/ypendulum-1.0.0rc1-py3-none-any.whl
```

所有内部运算使用 SI。配置可以写显式单位；Pint 是正式依赖。代码仍保留有限的后备单位解析器，以便诊断缺失依赖的受限环境，但正式科研运行应安装完整依赖。

## 最小工作流

A0 解析设计：

```bash
ypendulum validate-config configs/examples/analytic_3to2.yaml
ypendulum simulate configs/examples/analytic_3to2.yaml
ypendulum analyze runs/analytic_3to2
```

A1 精确环面基准：

```bash
ypendulum simulate configs/examples/ideal_3to2.yaml
ypendulum analyze runs/ideal_3to2
```

H1 三维柔索快速示例（符合冻结的 `12/12/20` quick 网格下限，采用集总质量以控制演示耗时）：

```bash
ypendulum validate-config configs/examples/full_quick_3to2.yaml
ypendulum equilibrate configs/examples/full_quick_3to2.yaml
ypendulum simulate configs/examples/full_quick_3to2.yaml
ypendulum analyze runs/full_quick_3to2
```

验证与收敛：

```bash
ypendulum validate-suite --fast
ypendulum validate-suite
ypendulum converge configs/examples/convergence_bdf_small.yaml
pytest -q
```

## CLI

```text
ypendulum validate-config CONFIG
ypendulum diagnose CONFIG [--output diagnosis.json]
ypendulum equilibrate CONFIG [--output FILE]
ypendulum simulate CONFIG
ypendulum analyze RUN_DIRECTORY
ypendulum modes CONFIG [--count N]
ypendulum compare RUN_A RUN_B
ypendulum compare-experiment RUN EXPERIMENT.csv [alignment options]
ypendulum converge CONFIG
ypendulum ablate CONFIG
ypendulum sweep SWEEP_YAML
ypendulum uncertainty UNCERTAINTY_YAML [--samples N] [--workers N]
ypendulum calibrate-axial DATA.csv --rest-length METRES
ypendulum calibrate-damping DATA.csv
ypendulum validate-suite [--fast]
ypendulum ui
```

`ablate` 在不重新拟合参数的条件下比较全模型、无气动、无材料黏性、近无质量绳、近无质量结点、高刚度极限和 A1。`uncertainty` 支持正态、截断正态、均匀、对数正态和离散分布，并报告失败样本比例与松绳概率。

## Python API

```python
from ypendulum import (
    load_config,
    diagnose_config,
    solve_static_equilibrium,
    simulate,
    analyze_run,
    analyze_linear_modes,
    compare_experiment,
    run_convergence_study,
)

cfg = load_config("configs/examples/full_quick_3to2.yaml")
equilibrium = solve_static_equilibrium(cfg)
result = simulate(cfg, equilibrium=equilibrium)
analysis = analyze_run(result.run_directory)
```

## 运行输出

每次运行目录包含：

```text
run_directory/
├── config_source.yaml          # 配置来自文件时保留原件
├── config_original.yaml        # 解析继承后的原始单位表达
├── config_resolved.yaml        # 统一 SI 数值
├── provenance.json             # 代码哈希、环境、依赖、容差和网格
├── result.h5                   # 全状态、张力、伸长、能量、频谱和观测量
├── summary.json
├── diagnostics.json
├── events.csv
├── report.md
├── analysis.json               # 执行 analyze 后生成
├── observer_output.npz         # 启用相机/投影时
└── plots/
```

HDF5 的物理数据集带 `unit` 与 `description` 属性。JSON 使用严格 JSON；非有限分析值写成 `null`，不会输出非标准 `NaN`/`Infinity`。

重启配置：

```yaml
initial_condition:
  type: restart
  state_file: path/to/result.h5
```

重启会检查节点标签、单元连接和自然长度；同样节点数但不同拓扑的文件会被拒绝。绝对仿真时间不会重置。

## 本地网页界面

```bash
python -m pip install -e '.[ui]'
ypendulum ui
```

界面源码包含 YAML 导入/导出、配置校验、量级诊断、静态几何预览、2D/3D 轨迹、张力、能量、频率可靠性、事件时间线、可选 A1 对照和完整运行目录下载。UI 只调用核心 API，不复制物理方程。当前受限环境缺少 Streamlit，浏览器级验收状态见 `CODEX_CONTINUATION_AND_ENVIRONMENT_GAPS.md`。

## 性能边界

高弹性模量、轻绳和细网格会产生比摆动频率高数个数量级的轴向模态。20/20/30 元素、`E=2 GPa` 的一致质量模型在通用 SciPy Radau 下可能非常昂贵。项目保留该路线作为高保真参考，但长时间低频研究应：

1. 先独立测量而不是任意增大 `E`；
2. 对实际材料损耗进行独立标定；
3. 使用 `quick`/较粗网格探索，再做 N/2N 收敛；
4. 在已证明低频结果不变时，用集总质量进行长时扫描，并以一致质量短窗交叉验证；
5. 对重新受拉峰值始终使用细网格和严格时间收敛。

真实基准与超时记录见 `benchmarks/performance_report.md`。软件不会把未运行的 60 s 生产网格伪装成已完成基准。

## 科学声明等级

软件区分 `DERIVED`、`VERIFIED`、`CALIBRATED`、`VALIDATED`、`PREDICTIVE` 和 `OUT_OF_SCOPE`。`VALIDATED`/`PREDICTIVE` 配置必须引用验证清单；`PREDICTIVE` 还会拒绝来源缺失、`assumed` 或 `fitted_target` 的关键参数。数值曲线与一条实验轨迹外观相似不构成实验验证。

## 文档索引

- `docs/frozen_specification.md`：冻结执行规范；
- `docs/theory_source.md`：统一理论长文；
- `docs/theory.md`：软件实际实现的物理模型；
- `docs/numerical_method.md`：离散化、求解器和功—能审计；
- `docs/user_guide.md`：配置、CLI、重启、消融与不确定度；
- `docs/api.md`：公共 API 和结果对象；
- `docs/limitations.md`：边界、未验证项和失败模式；
- `validation/validation_report.md`：V-001 至 V-013 实际结果；
- `validation/convergence_report.md`：N/2N、时间精度和 Radau/BDF 对照；
- `validation/adversarial_review.md`：发布前对抗性审查；
- `validation/release_audit.md`：构建、安装和测试审计；
- `validation/actual_test_run_summary.md`：实际命令、数值和未完成验收。

## 许可证

MIT。第三方依赖保留其各自许可证。研究使用时应同时保留配置、参数来源、代码哈希、数值容差、网格和验证状态。
