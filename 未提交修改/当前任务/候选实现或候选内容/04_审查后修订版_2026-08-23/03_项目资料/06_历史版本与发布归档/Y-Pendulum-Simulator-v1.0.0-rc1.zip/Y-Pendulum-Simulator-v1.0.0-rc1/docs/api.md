# Python API

## 核心入口

```python
from ypendulum import (
    load_config,
    diagnose_config,
    solve_static_equilibrium,
    simulate,
    analyze_run,
    analyze_linear_modes,
    compare_experiment,
    run_convergence_study,
)
```

### `load_config(path_or_mapping)`

解析 YAML/字典、绳配置继承、单位和物理一致性。返回 `SimulationConfig`。相对材料表、支点轨迹、重启文件和验证清单路径相对于配置文件解析。

### `diagnose_config(config, solve_equilibrium=True, write_output=None)`

不积分动力学。返回量级、范围、观测可辨识性、数值解析能力、参数来源和声明上限。H1 默认先求静平衡。

### `solve_static_equilibrium(config, model=None)`

返回 `StaticEquilibrium`：加载位置、速度、最大自由节点力残差、迭代数和局部稳定性特征值审计。

### `simulate(config, equilibrium=None, write_output=True)`

按 `run.mode` 返回：

- A0：`AnalyticPrediction`
- A1：`TorusResult`
- H1：`SimulationResult`

H1 的 `SimulationResult` 包含 `time, positions, velocities, tension, stretch, active, energy, reactions, events, diagnostics`。

### `analyze_linear_modes(config, count=2)`

H1 中由同一静力切线和质量矩阵求小振动广义特征值，并报告摆球动能参与率、方向和结点/摆球位移比。它不是有限振幅频率。

### `analyze_run(run_directory)`

从已保存运行重新提取主频、可靠性、相位漂移、闭合误差和能量指标。记录不足三个周期或存在结构切换时不会伪报稳定双主频。

### `compare_experiment(...)`

将冻结运行与 `time,x,y,z` 或 `time,u_pixel,v_pixel` CSV 作前向比较。默认无对齐拟合；显式启用的时间平移、平移和旋转会列入报告。

### `run_convergence_study(config)`

运行 N/2N、production/reference、Radau/BDF 比较，包含轨迹、低频、张力、能量、事件时刻，以及存在重新受拉时的峰值和窗口冲量差。

## 材料标定 API

```python
from ypendulum.calibration import (
    fit_axial_stiffness,
    build_tabulated_tension_extension,
    compare_envelope_models,
)
```

标定函数只接受 SI 数组。任何系统性仪器误差和数据分组策略由调用方显式管理。

## 低层接口

`FullCableModel.evaluate(t, q_free, v_free, compute_tangent=True)` 返回完整力、元素张力、弹性能、耗散、活跃集和位置/速度切线。低层接口可能随实现演化；公共工作流优先使用上述入口。
