# 用户手册

## 1. 推荐工作流

1. 用 A0 设计目标频率比和几何。
2. 用 A1 检查有限振幅、理想张力范围和快速轨迹。
3. 测量几何、质量、绳直径、密度、轴向加载曲线和阻尼包络。
4. 运行 `ypendulum diagnose CONFIG`，确认目标观测量的时间窗、采样、网格和声明等级可用。
5. H1 先用 quick 网格探索，再做 N/2N、production/reference 和跨求解器收敛。
6. 将校准参数冻结后，才打开封存验证数据并运行 `compare-experiment`。

## 2. 安装

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e .
```

UI：

```bash
python -m pip install -e '.[ui]'
ypendulum ui
```

## 3. 配置要点

所有物理量推荐使用 `{value, unit, source, uncertainty}`。`rest_length` 是无载自然长度，不是加载后的直线距离。表格本构还应写入标定试样长度：

```yaml
material_model: tabulated_tension_extension
table_file: material_curve.csv
table_calibration_length: {value: 0.500, unit: m, source: calibrated_independent}
```

材料表固定列名：`extension,tension`，单位分别为 m、N，且从 `(0,0)` 开始、加载支路单调。若存在明显滞回，单值表格不适用。

## 4. 常用命令

```bash
ypendulum validate-config CONFIG
ypendulum diagnose CONFIG --output diagnosis.json
ypendulum equilibrate CONFIG
ypendulum modes CONFIG --count 4
ypendulum simulate CONFIG
ypendulum analyze RUN_DIRECTORY
ypendulum compare RUN_A RUN_B
ypendulum converge CONFIG
ypendulum ablate CONFIG
ypendulum sweep configs/sweep_example.yaml
ypendulum uncertainty configs/uncertainty_example.yaml --samples 100
```

独立轴向标定：

```bash
ypendulum calibrate-axial axial.csv \
  --rest-length 0.500 \
  --output axial_fit.json \
  --table-output material_curve.csv
```

输入列默认 `force_N,extension_m`。程序报告 \(EA\)、普通最小二乘标准误差和 95% 区间；系统误差仍需单独传播。

阻尼包络诊断：

```bash
ypendulum calibrate-damping damping.csv --output damping_fit.json
```

输入列默认 `time_s,amplitude_m`。它只在指数与反比例包络之间做诊断，不证明唯一耗散机制。

实验比较：

```bash
ypendulum compare-experiment runs/test trajectory.csv \
  --output-directory comparison
```

默认不拟合任何对齐参数。可显式启用有限时间平移、平面平移和旋转，但这些 nuisance 参数必须在验证集揭示前冻结。

## 5. 初始条件

- `static_equilibrium`：加载静平衡。
- `reduced_angles_release`：以加载几何定义快/慢角，固定摆球求条件静力后释放。
- `cartesian_release`：固定指定摆球位置，求其余自由节点条件平衡。
- `direct_state`：读取完整节点位置/速度数组。
- `restart`：从兼容 H1 HDF5 最后状态继续，绝对时间不重置。

瞬间解除固定摆球约束可能真实激发纵波；这不是自动数值错误。释放装置若有有限加速度历程，应将其作为规定边界/外力建模。

## 6. 诊断解释

`diagnose` 分别给出：

- 相位预算要求的频率精度；
- 有限振幅、结点/绳质量、轴向伸长、绳波、气动和支点运动量级；
- 松绳角裕量；
- 输出样本/周期和观测周期数；
- 内部步长、输出采样对纵波与重新受拉峰值的解析能力；
- 参数来源缺口；
- 当前配置最多支持的科学声明等级。

“低频轨迹可用”不等于“张力峰可用”。后者需要 `resolve_longitudinal_waves: true`、更小内部步长、更密输出以及专门的网格/时间收敛。

## 7. 结果目录

`result.h5` 保存全节点状态、每个元素张力/伸长/活跃状态、支点反力、能量与观测输出。所有数据集带单位和说明。`diagnostics.json` 分为 `solver_and_model`、`preflight` 和 `result_validity` 三部分。

## 8. 科学声明

- `DERIVED`：方程/配置已形成，但未完成数值验证。
- `VERIFIED`：解析、单元和数值实现验证通过。
- `CALIBRATED`：关键参数由独立实验得到。
- `VALIDATED`：冻结模型在封存验证运行上通过预设指标。
- `PREDICTIVE`：进一步通过未见几何/释放条件。

`VALIDATED/PREDICTIVE` 必须引用真实存在、冻结且通过的验证清单；软件会检查清单结构，但不能替代科研数据管理责任。
