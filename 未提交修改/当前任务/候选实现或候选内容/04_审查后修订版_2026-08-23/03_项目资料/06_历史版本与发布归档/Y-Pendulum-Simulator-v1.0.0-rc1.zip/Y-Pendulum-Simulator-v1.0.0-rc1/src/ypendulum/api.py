"""Public orchestration API."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import h5py
import matplotlib.pyplot as plt
import numpy as np
import yaml

from ypendulum.analysis import (
    analytic_phase,
    assess_result_validity,
    automatic_scale_diagnostics,
    compare_run_to_experiment as _compare_run_to_experiment,
    dominant_frequency_estimates,
    energy_audit,
    power_spectrum,
    linear_phase_drift,
    linearised_mode_summary,
    modal_coordinates,
    resonant_phase,
    state_closure_error,
)
from ypendulum.config import SimulationConfig, load_config, resolved_config_dict
from ypendulum.config.units import as_vector3, to_si
from ypendulum.io import (
    build_provenance,
    read_h1_result,
    sha256_bytes,
    write_events,
    write_h1_result,
    write_json,
    write_run_report,
)
from ypendulum.models.analytic import predict_analytic
from ypendulum.models.full_cable import FullCableModel
from ypendulum.models.state import SimulationResult, StaticEquilibrium, TorusResult
from ypendulum.models.torus import simulate_torus
from ypendulum.observers import PinholeCamera, sample_with_exposure
from ypendulum.solvers.dynamic import simulate_full
from ypendulum.solvers.convergence import run_convergence_matrix
from ypendulum.solvers.static import solve_static_equilibrium


def _project_observer(cfg: SimulationConfig, result: SimulationResult) -> tuple[np.ndarray | None, np.ndarray | None]:
    bob = result.positions[:, -1]  # Bob is deliberately the final topology node.
    if cfg.observer.type == "orthographic_xy":
        return result.time.copy(), bob[:, :2].copy()
    camera_cfg = cfg.observer.camera
    assert camera_cfg is not None
    K = np.asarray(camera_cfg.intrinsic_matrix, dtype=float)
    R = np.asarray(camera_cfg.rotation_world_to_camera, dtype=float)
    t = as_vector3(camera_cfg.translation_world_to_camera, default_unit="m")
    camera = PinholeCamera(K, R, t, tuple(float(v) for v in camera_cfg.distortion))
    pixels = camera.project(bob)
    frame_rate = float(to_si(camera_cfg.frame_rate, default_unit="Hz"))
    exposure = float(to_si(camera_cfg.exposure_time, default_unit="s"))
    return sample_with_exposure(
        result.time, pixels, frame_rate=frame_rate, exposure_time=exposure
    )


def _analysis_from_arrays(
    cfg: SimulationConfig,
    time: np.ndarray,
    bob_position: np.ndarray,
    bob_velocity: np.ndarray | None,
    support_a: np.ndarray,
    support_b: np.ndarray,
    gravity: np.ndarray,
) -> dict[str, Any]:
    x, y, basis = modal_coordinates(bob_position, support_a, support_b, gravity)
    duration = float(time[-1] - time[0])
    max_frequency = 0.4 / float(np.median(np.diff(time)))
    estimates = dominant_frequency_estimates(
        time,
        np.column_stack([x, y]),
        maximum_frequency=max_frequency,
        minimum_cycles=3.0,
    )
    estimate_fast, estimate_slow = estimates
    candidate_fast = float(estimate_fast.frequency_hz)
    candidate_slow = float(estimate_slow.frequency_hz)
    frequency_reliable = bool(estimate_fast.reliable and estimate_slow.reliable)
    freq_fast = candidate_fast if frequency_reliable else float("nan")
    freq_slow = candidate_slow if frequency_reliable else float("nan")
    p, q = cfg.analysis.target_ratio
    ratio = float(freq_fast / freq_slow) if frequency_reliable and freq_slow > 0.0 else float("nan")
    phase_drift = float("nan")
    hilbert_phase_drift = float("nan")
    phase_rms = float("nan")
    closure = float("nan")
    if frequency_reliable:
        phase_drift = float(2.0 * np.pi * (q * freq_fast - p * freq_slow))
        phf = analytic_phase(time, x, center_frequency=freq_fast)
        phs = analytic_phase(time, y, center_frequency=freq_slow)
        resonant = resonant_phase(phf, phs, p, q)
        edge = max(0.1 * duration, 1.0 / max(freq_slow, 1e-12))
        interior = (time >= time[0] + edge) & (time <= time[-1] - edge)
        if np.count_nonzero(interior) >= 16:
            hilbert_phase_drift, phase_rms = linear_phase_drift(time[interior], resonant[interior])
        nominal = q / freq_slow
        if bob_velocity is None:
            state = np.column_stack([x, y])
        else:
            velocity = np.asarray(bob_velocity, dtype=float)
            vx = velocity @ basis.fast
            vy = velocity @ basis.slow
            state = np.column_stack([x, y, vx, vy])
        closure = state_closure_error(time, state, nominal)
    return {
        "duration_s": duration,
        "frequency_fast_hz": float(freq_fast),
        "frequency_slow_hz": float(freq_slow),
        "frequency_ratio": ratio,
        "frequency_analysis_reliable": frequency_reliable,
        "frequency_candidate_fast_hz": candidate_fast,
        "frequency_candidate_slow_hz": candidate_slow,
        "frequency_fast_fit_r2": float(estimate_fast.fit_r2),
        "frequency_slow_fit_r2": float(estimate_slow.fit_r2),
        "frequency_fast_observed_cycles": float(estimate_fast.observed_cycles),
        "frequency_slow_observed_cycles": float(estimate_slow.observed_cycles),
        "frequency_fast_reliability_reason": estimate_fast.reason,
        "frequency_slow_reliability_reason": estimate_slow.reason,
        "target_ratio": [p, q],
        "phase_drift_rad_s": phase_drift,
        "hilbert_phase_drift_rad_s": hilbert_phase_drift,
        "phase_fit_rms_rad": phase_rms,
        "state_closure_error": closure,
    }


def _write_common_config(run_dir: Path, cfg: SimulationConfig) -> tuple[dict[str, Any], str]:
    run_dir.mkdir(parents=True, exist_ok=True)
    original = cfg.model_dump(mode="python", exclude={"source_path"})
    resolved = resolved_config_dict(cfg)
    (run_dir / "config_original.yaml").write_text(
        yaml.safe_dump(original, sort_keys=False, allow_unicode=True), encoding="utf-8"
    )
    resolved_text = yaml.safe_dump(resolved, sort_keys=False, allow_unicode=True)
    (run_dir / "config_resolved.yaml").write_text(resolved_text, encoding="utf-8")
    if cfg.source_path and Path(cfg.source_path).exists():
        (run_dir / "config_source.yaml").write_bytes(Path(cfg.source_path).read_bytes())
    return resolved, sha256_bytes(resolved_text.encode())



def _write_analytic_hdf5(path: Path, prediction) -> None:
    units = {
        "lower_length": "m",
        "upper_drop": "m",
        "slow_length": "m",
        "omega_fast": "rad/s",
        "omega_slow": "rad/s",
        "frequency_ratio": "1",
        "detuning": "rad/s",
        "drift_time": "s",
        "nominal_close_time": "s",
        "h_over_l": "1",
    }
    with h5py.File(path, "w") as h5:
        h5.attrs["format"] = "YP-FPSim A0 result"
        h5.attrs["format_version"] = "1.0"
        h5.attrs["model"] = "A0"
        for key, value in prediction.__dict__.items():
            if key == "target_ratio":
                ds = h5.create_dataset("/analytic/target_ratio", data=np.asarray(value, dtype=int))
                ds.attrs["unit"] = "1"
                ds.attrs["description"] = "Target fast:slow integer ratio p,q"
                continue
            ds = h5.create_dataset(f"/analytic/{key}", data=value)
            ds.attrs["unit"] = units.get(key, "1")
            ds.attrs["description"] = key.replace("_", " ")

def _write_torus_hdf5(path: Path, result: TorusResult) -> None:
    with h5py.File(path, "w") as h5:
        h5.attrs["format"] = "YP-FPSim A1 result"
        h5.attrs["model"] = "A1"
        for name, data, unit, description in (
            ("/time", result.time, "s", "Simulation time"),
            ("/state/generalized", result.state, "mixed", "phi,theta,phi_dot,theta_dot"),
            ("/bodies/bob/position", result.position, "m", "Bob position"),
            ("/cables/tension", result.tensions, "N", "upper_A,upper_B,lower tensions"),
            ("/energy/mechanical", result.energy, "J", "Conserved A1 energy"),
        ):
            ds = h5.create_dataset(name, data=data)
            ds.attrs["unit"] = unit
            ds.attrs["description"] = description



def _append_analysis_hdf5(
    path: Path,
    cfg: SimulationConfig,
    time: np.ndarray,
    bob_position: np.ndarray,
    support_a: np.ndarray,
    support_b: np.ndarray,
    gravity: np.ndarray,
    summary: dict[str, Any],
) -> None:
    """Persist modal coordinates, spectra and phase series in the run HDF5."""

    x, y, _basis = modal_coordinates(bob_position, support_a, support_b, gravity)
    spectrum_fast = power_spectrum(time, x) if cfg.analysis.compute_spectrum else None
    spectrum_slow = power_spectrum(time, y) if cfg.analysis.compute_spectrum else None
    phase_fast = phase_slow = phase_resonant = None
    if summary.get("frequency_analysis_reliable", False):
        ff = float(summary["frequency_fast_hz"])
        fs = float(summary["frequency_slow_hz"])
        phase_fast = analytic_phase(time, x, center_frequency=ff)
        phase_slow = analytic_phase(time, y, center_frequency=fs)
        p, q = cfg.analysis.target_ratio
        phase_resonant = resonant_phase(phase_fast, phase_slow, p, q)

    with h5py.File(path, "a") as h5:
        group = h5.require_group("/analysis")
        group.attrs["frequency_analysis_reliable"] = bool(
            summary.get("frequency_analysis_reliable", False)
        )
        group.attrs["target_ratio_p"] = int(cfg.analysis.target_ratio[0])
        group.attrs["target_ratio_q"] = int(cfg.analysis.target_ratio[1])

        def put(name: str, data: np.ndarray, unit: str, description: str) -> None:
            if name in h5:
                del h5[name]
            ds = h5.create_dataset(name, data=np.asarray(data), compression="gzip")
            ds.attrs["unit"] = unit
            ds.attrs["description"] = description

        put("/analysis/modal/fast", x, "m", "Bob displacement along the support-axis fast coordinate")
        put("/analysis/modal/slow", y, "m", "Bob displacement along the transverse slow coordinate")
        if spectrum_fast is not None and spectrum_slow is not None:
            put(
                "/analysis/spectrum/frequency",
                spectrum_fast["frequency_hz"],
                "Hz",
                "Welch spectrum frequency bins",
            )
            put(
                "/analysis/spectrum/fast_power",
                spectrum_fast["power"],
                "m^2/Hz",
                "Welch power spectral density of the fast modal coordinate",
            )
            put(
                "/analysis/spectrum/slow_power",
                spectrum_slow["power"],
                "m^2/Hz",
                "Welch power spectral density of the slow modal coordinate",
            )
            h5["/analysis/spectrum"].attrs["window"] = spectrum_fast["window"]
            h5["/analysis/spectrum"].attrs["sample_rate_hz"] = spectrum_fast[
                "sample_rate_hz"
            ]
            h5["/analysis/spectrum"].attrs["nperseg"] = spectrum_fast["nperseg"]
        if phase_fast is not None and phase_slow is not None and phase_resonant is not None:
            put("/analysis/phase/fast", phase_fast, "rad", "Unwrapped analytic fast-mode phase")
            put("/analysis/phase/slow", phase_slow, "rad", "Unwrapped analytic slow-mode phase")
            put(
                "/analysis/phase/resonant",
                phase_resonant,
                "rad",
                "Unwrapped q*fast - p*slow resonant phase",
            )

def _write_standard_plots(run_dir: Path, result, *, model=None) -> None:
    """Write deterministic diagnostic figures without duplicating physics logic."""

    plot_dir = run_dir / "plots"
    plot_dir.mkdir(parents=True, exist_ok=True)
    if isinstance(result, TorusResult):
        bob = result.position
        time = result.time
        tension = result.tensions
        energy = result.energy
        labels = ["upper_A", "upper_B", "lower"]
    elif isinstance(result, SimulationResult):
        bob = result.positions[:, -1]
        time = result.time
        assert model is not None
        tension = np.column_stack(
            [
                np.max(result.tension[:, model.topology.cable_slices[name]], axis=1)
                for name in ("upper_A", "upper_B", "lower")
            ]
        )
        energy = result.energy["balance_residual"]
        labels = ["upper_A", "upper_B", "lower"]
    else:
        return

    fig, ax = plt.subplots()
    ax.plot(bob[:, 0], bob[:, 1])
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlabel("x [m]")
    ax.set_ylabel("y [m]")
    fig.tight_layout()
    fig.savefig(plot_dir / "lissajous_xy.png", dpi=160)
    plt.close(fig)

    fig, ax = plt.subplots()
    for index, label in enumerate(labels):
        ax.plot(time, tension[:, index], label=label)
    ax.set_xlabel("time [s]")
    ax.set_ylabel("tension [N]")
    ax.legend()
    fig.tight_layout()
    fig.savefig(plot_dir / "tension.png", dpi=160)
    plt.close(fig)

    fig, ax = plt.subplots()
    if isinstance(result, TorusResult):
        denominator = max(abs(float(energy[0])), 1.0e-12)
        ax.plot(time, (energy - energy[0]) / denominator)
        ax.set_ylabel("relative energy drift")
    else:
        ax.plot(time, energy)
        ax.set_ylabel("energy balance residual")
    ax.set_xlabel("time [s]")
    fig.tight_layout()
    fig.savefig(plot_dir / "energy_audit.png", dpi=160)
    plt.close(fig)



def diagnose_config(
    config: SimulationConfig | str | Path | dict[str, Any],
    *,
    solve_equilibrium: bool = True,
    write_output: str | Path | None = None,
) -> dict[str, Any]:
    """Run preflight scale, scope, observability and claim diagnostics.

    For H1 configurations the default performs the static solve because loaded
    geometry, prestress and wave scales are more relevant than natural geometry.
    This command does not perform a dynamic simulation.
    """

    cfg = config if isinstance(config, SimulationConfig) else load_config(config)
    model = FullCableModel(cfg)
    equilibrium = None
    if solve_equilibrium and cfg.run.mode == "full":
        equilibrium = solve_static_equilibrium(cfg, model)
    report = automatic_scale_diagnostics(cfg, model, equilibrium=equilibrium)
    report["run_name"] = cfg.run.name
    report["mode"] = cfg.run.mode
    if equilibrium is not None:
        report["static_equilibrium"] = {
            "converged": equilibrium.converged,
            "force_residual_max_N": equilibrium.force_residual_max,
            "iterations": equilibrium.iterations,
            "metadata": equilibrium.metadata,
        }
    if write_output is not None:
        write_json(Path(write_output), report)
    return report

def simulate(
    config: SimulationConfig | str | Path | dict[str, Any],
    *,
    equilibrium: StaticEquilibrium | None = None,
    write_output: bool = True,
):
    cfg = config if isinstance(config, SimulationConfig) else load_config(config)
    run_dir = Path(cfg.run.output_directory).expanduser().resolve()
    resolved, config_hash = _write_common_config(run_dir, cfg) if write_output else ({}, "")

    if cfg.run.mode == "analytic":
        prediction = predict_analytic(cfg)
        summary = {
            "run_name": cfg.run.name,
            "model": "A0",
            "claim_level": cfg.run.claim_level,
            "status": "success",
            **prediction.__dict__,
        }
        if write_output:
            _write_analytic_hdf5(run_dir / "result.h5", prediction)
            write_json(run_dir / "summary.json", summary)
            provenance = build_provenance(
                project_root=Path(__file__).resolve().parents[2],
                config_hash=config_hash,
                seed=cfg.run.seed,
                solver={"method": "analytic"},
                mesh={"model": "A0", "elements": 0},
                claim_level=cfg.run.claim_level,
                assumptions=["linear small-amplitude analytic model"],
            )
            write_json(run_dir / "provenance.json", provenance)
            write_run_report(run_dir / "report.md", summary, {})
        return prediction

    if cfg.run.mode == "torus":
        result = simulate_torus(cfg)
        support_a = as_vector3(cfg.supports.A.position, default_unit="m")
        support_b = as_vector3(cfg.supports.B.position, default_unit="m")
        gravity = as_vector3(cfg.environment.gravity, default_unit="m/s^2")
        summary = {
            "run_name": cfg.run.name,
            "model": "A1",
            "claim_level": cfg.run.claim_level,
            "status": "success",
            **_analysis_from_arrays(
                cfg, result.time, result.position, None, support_a, support_b, gravity
            ),
            "max_relative_energy_drift": float(
                np.max(np.abs(result.energy - result.energy[0]))
                / max(abs(float(result.energy[0])), 1e-12)
            ),
            "event": result.event,
        }
        if write_output:
            _write_torus_hdf5(run_dir / "result.h5", result)
            _append_analysis_hdf5(
                run_dir / "result.h5",
                cfg,
                result.time,
                result.position,
                support_a,
                support_b,
                gravity,
                summary,
            )
            write_json(run_dir / "summary.json", summary)
            write_json(run_dir / "diagnostics.json", {"event": result.event})
            write_events(run_dir / "events.csv", [] if result.event is None else [result.event])
            provenance = build_provenance(
                project_root=Path(__file__).resolve().parents[2],
                config_hash=config_hash,
                seed=cfg.run.seed,
                solver={"method": "DOP853", "rtol": 1e-10, "atol": 1e-12},
                mesh={"model": "A1", "elements": 0},
                claim_level=cfg.run.claim_level,
                assumptions=["massless inextensible strings", "massless junction", "all-taut until event"],
            )
            write_json(run_dir / "provenance.json", provenance)
            write_run_report(run_dir / "report.md", summary, {"event": result.event})
            _write_standard_plots(run_dir, result)
        return result

    model = FullCableModel(cfg)
    preflight = automatic_scale_diagnostics(cfg, model, equilibrium=equilibrium)
    result = simulate_full(cfg, model=model, equilibrium=equilibrium)
    preflight = automatic_scale_diagnostics(
        cfg, model, loaded_positions=result.positions[0]
    )
    validity = assess_result_validity(cfg, model, result, preflight=preflight)
    result.run_directory = run_dir if write_output else None
    support_a = result.positions[0, 0]
    support_b = result.positions[0, 1]
    gravity = model.gravity
    bob = result.positions[:, model.topology.bob_node]
    bob_v = result.velocities[:, model.topology.bob_node]
    summary = {
        "run_name": cfg.run.name,
        "model": "H1",
        "claim_level": cfg.run.claim_level,
        "status": "success",
        **_analysis_from_arrays(cfg, result.time, bob, bob_v, support_a, support_b, gravity),
        "minimum_tension_N": float(np.min(result.tension)),
        "maximum_tension_N": float(np.max(result.tension)),
        "event_count": len(result.events),
        "configuration_claim_cap": preflight["claim_readiness"]["configuration_claim_cap"],
        "requested_claim_supported": preflight["claim_readiness"]["requested_claim_supported"],
        "run_validity_status": validity["status"],
        "observable_support": validity["observable_support"],
        **energy_audit(result.energy),
    }
    structural_events = [
        event
        for event in result.events
        if event.get("type")
        in {
            "cable_slack",
            "cable_retension",
            "cable_initially_not_fully_taut",
            "cable_fully_unloaded",
            "cable_first_local_retension",
            "upper_branch_switch",
            "element_slack",
            "element_retension",
        }
    ]
    if structural_events:
        summary["frequency_analysis_reliable"] = False
        summary["frequency_analysis_note"] = (
            "Structural slack/retension events make a stationary two-frequency fit invalid."
        )
    if write_output:
        observer_time, observer_values = _project_observer(cfg, result)
        write_h1_result(
            run_dir / "result.h5",
            result,
            model,
            observer_pixels=observer_values if cfg.observer.type == "pinhole" else None,
            observer_time=observer_time if cfg.observer.type == "pinhole" else None,
        )
        _append_analysis_hdf5(
            run_dir / "result.h5",
            cfg,
            result.time,
            bob,
            support_a,
            support_b,
            gravity,
            summary,
        )
        if observer_values is not None:
            np.savez_compressed(
                run_dir / "observer_output.npz", time=observer_time, values=observer_values
            )
        write_json(run_dir / "summary.json", summary)
        combined_diagnostics = {
            "solver_and_model": result.diagnostics,
            "preflight": preflight,
            "result_validity": validity,
        }
        write_json(run_dir / "diagnostics.json", combined_diagnostics)
        write_events(run_dir / "events.csv", result.events)
        provenance = build_provenance(
            project_root=Path(__file__).resolve().parents[2],
            config_hash=config_hash,
            seed=cfg.run.seed,
            solver={
                key: result.diagnostics.get(key)
                for key in (
                    "solver_method",
                    "solver_profile",
                    "rtol",
                    "position_atol",
                    "velocity_atol",
                    "max_step",
                    "jacobian_kind",
                )
            },
            mesh={
                "nodes": model.topology.node_count,
                "elements": model.topology.elements.count,
                "cable_elements": {
                    name: sl.stop - sl.start for name, sl in model.topology.cable_slices.items()
                },
                "mass_matrix": cfg.solver.mass_matrix,
            },
            claim_level=cfg.run.claim_level,
            assumptions=[
                "fixed material knot; no sliding",
                "axial cable/truss; no bending or torsion",
                "bob force line through centre of mass",
            ],
        )
        write_json(run_dir / "provenance.json", provenance)
        write_run_report(run_dir / "report.md", summary, combined_diagnostics)
        _write_standard_plots(run_dir, result, model=model)
    return result


def analyze_run(run: str | Path | SimulationResult) -> dict[str, Any]:
    if isinstance(run, SimulationResult):
        if run.run_directory is None:
            return {
                "model": run.model_name,
                "duration_s": float(run.time[-1] - run.time[0]),
                **energy_audit(run.energy),
            }
        directory = run.run_directory
    else:
        directory = Path(run)
    config_path = directory / "config_original.yaml"
    cfg = load_config(config_path)
    if not (directory / "result.h5").exists():
        summary_path = directory / "summary.json"
        if summary_path.exists():
            return json.loads(summary_path.read_text(encoding="utf-8"))
        raise FileNotFoundError(f"No result.h5 or summary.json found in {directory}.")
    with h5py.File(directory / "result.h5", "r") as h5:
        model_name = str(h5.attrs.get("model", "H1"))
    if model_name == "A0":
        summary_path = directory / "summary.json"
        if summary_path.exists():
            analysis = json.loads(summary_path.read_text(encoding="utf-8"))
        else:
            with h5py.File(directory / "result.h5", "r") as h5:
                analysis = {
                    "model": "A0",
                    **{key: np.asarray(value)[()].tolist() if np.asarray(value).ndim else float(np.asarray(value)[()])
                       for key, value in h5["/analytic"].items()},
                }
        write_json(directory / "analysis.json", analysis)
        return analysis
    if model_name == "A1":
        with h5py.File(directory / "result.h5", "r") as h5:
            time = np.asarray(h5["/time"])
            bob = np.asarray(h5["/bodies/bob/position"])
            energy = np.asarray(h5["/energy/mechanical"])
        support_a = as_vector3(cfg.supports.A.position, default_unit="m")
        support_b = as_vector3(cfg.supports.B.position, default_unit="m")
        gravity = as_vector3(cfg.environment.gravity, default_unit="m/s^2")
        analysis = _analysis_from_arrays(
            cfg, time, bob, None, support_a, support_b, gravity
        )
        analysis["model"] = "A1"
        analysis["max_relative_energy_drift"] = float(
            np.max(np.abs(energy - energy[0])) / max(abs(float(energy[0])), 1.0e-12)
        )
        write_json(directory / "analysis.json", analysis)
        return analysis
    data = read_h1_result(directory / "result.h5")
    support_a = data["positions"][0, 0]
    support_b = data["positions"][0, 1]
    gravity = as_vector3(cfg.environment.gravity, default_unit="m/s^2")
    analysis = _analysis_from_arrays(
        cfg,
        data["time"],
        data["bob_position"],
        None,
        support_a,
        support_b,
        gravity,
    )
    analysis["max_abs_energy_balance_residual"] = float(
        np.max(np.abs(data["energy_balance_residual"]))
    )
    write_json(directory / "analysis.json", analysis)
    return analysis



def analyze_linear_modes(
    config: SimulationConfig | str | Path | dict[str, Any],
    *,
    count: int = 2,
) -> dict[str, Any]:
    """Compute small-vibration modes from the H1 static equilibrium."""

    cfg = config if isinstance(config, SimulationConfig) else load_config(config)
    if cfg.run.mode != "full":
        prediction = predict_analytic(cfg)
        return {
            "model": "A0 analytic limit",
            "claim_level": cfg.run.claim_level,
            "modes": [
                {"descriptive_label": "transverse_slow", "angular_frequency_rad_s": prediction.omega_slow, "frequency_hz": prediction.omega_slow / (2.0 * np.pi)},
                {"descriptive_label": "support_axis_fast", "angular_frequency_rad_s": prediction.omega_fast, "frequency_hz": prediction.omega_fast / (2.0 * np.pi)},
            ],
        }
    if count < 1:
        raise ValueError("Mode count must be positive.")
    model = FullCableModel(cfg)
    equilibrium = solve_static_equilibrium(cfg, model)
    modes = linearised_mode_summary(model, equilibrium.positions, count=count)
    return {
        "model": "H1 linearisation",
        "claim_level": cfg.run.claim_level,
        "static_force_residual_N": equilibrium.force_residual_max,
        "node_count": model.topology.node_count,
        "element_count": model.topology.elements.count,
        "modes": modes,
        "diagnostics": model.diagnostics(),
    }

def run_convergence_study(
    config: SimulationConfig | str | Path | dict[str, Any],
    *,
    write_output: bool = True,
) -> dict[str, Any]:
    cfg = config if isinstance(config, SimulationConfig) else load_config(config)
    if cfg.run.mode != "full":
        raise ValueError("Convergence study requires full H1 mode.")
    output = None
    if write_output:
        output = Path(cfg.run.output_directory).parent / f"{cfg.run.name}_convergence"
    return run_convergence_matrix(cfg, output_directory=output)


def compare_runs(run_a: str | Path, run_b: str | Path) -> dict[str, Any]:
    def generic(directory: str | Path) -> dict[str, np.ndarray]:
        path = Path(directory) / "result.h5"
        with h5py.File(path, "r") as h5:
            return {
                "time": np.asarray(h5["/time"]),
                "bob_position": np.asarray(h5["/bodies/bob/position"]),
            }

    a = generic(run_a)
    b = generic(run_b)
    t = a["time"]
    bob_b = np.column_stack(
        [np.interp(t, b["time"], b["bob_position"][:, j]) for j in range(3)]
    )
    diff = a["bob_position"] - bob_b
    scale = max(float(np.sqrt(np.mean((a["bob_position"] - np.mean(a["bob_position"], axis=0)) ** 2))), 1e-12)
    return {
        "trajectory_normalized_rms": float(np.sqrt(np.mean(diff**2)) / scale),
        "maximum_position_difference_m": float(np.max(np.linalg.norm(diff, axis=1))),
        "run_a": str(run_a),
        "run_b": str(run_b),
    }


def compare_experiment(
    run_directory: str | Path,
    experiment_csv: str | Path,
    *,
    estimate_time_shift: bool = False,
    maximum_time_shift_s: float = 0.0,
    estimate_translation: bool = False,
    estimate_planar_rotation: bool = False,
    output_directory: str | Path | None = None,
) -> dict[str, Any]:
    """Compare a frozen forward run with experimental positions or pixels."""

    from ypendulum.analysis.experiment import AlignmentOptions
    options = AlignmentOptions(
        estimate_time_shift=estimate_time_shift,
        maximum_time_shift_s=maximum_time_shift_s,
        estimate_translation=estimate_translation,
        estimate_planar_rotation=estimate_planar_rotation,
    )
    return _compare_run_to_experiment(
        run_directory,
        experiment_csv,
        options=options,
        output_directory=output_directory,
    )
