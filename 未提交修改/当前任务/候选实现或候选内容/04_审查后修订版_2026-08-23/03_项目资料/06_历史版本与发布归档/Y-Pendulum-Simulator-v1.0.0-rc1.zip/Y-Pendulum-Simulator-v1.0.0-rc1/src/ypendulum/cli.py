"""Command-line interface for YP-FPSim."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

from ypendulum.analysis import automatic_scale_diagnostics
from ypendulum.analysis.ablation import run_ablation
from ypendulum.analysis.sweep import run_sweep
from ypendulum.analysis.uncertainty import run_uncertainty
from ypendulum.calibration import (
    build_tabulated_tension_extension,
    compare_envelope_models,
    fit_axial_stiffness,
)
from ypendulum.api import analyze_linear_modes, analyze_run, compare_experiment, compare_runs, diagnose_config, run_convergence_study, simulate
from ypendulum.config import load_config, resolved_config_dict
from ypendulum.io import json_safe, sha256_file, write_json
from ypendulum.models.full_cable import FullCableModel
from ypendulum.solvers.static import solve_static_equilibrium
from ypendulum.version import __version__


def _print(payload) -> None:
    print(json.dumps(json_safe(payload), indent=2, ensure_ascii=False, allow_nan=False))


def cmd_validate_config(args) -> int:
    cfg = load_config(args.config)
    model = FullCableModel(cfg) if cfg.run.mode == "full" else None
    payload = {
        "valid": True,
        "run_name": cfg.run.name,
        "mode": cfg.run.mode,
        "claim_level": cfg.run.claim_level,
        "resolved": resolved_config_dict(cfg),
        "scale_diagnostics": None if model is None else automatic_scale_diagnostics(cfg, model),
    }
    _print(payload)
    return 0


def cmd_diagnose(args) -> int:
    report = diagnose_config(
        args.config,
        solve_equilibrium=not args.skip_equilibrium,
        write_output=args.output,
    )
    _print(report)
    return 0 if report["claim_readiness"]["requested_claim_supported"] else 2


def cmd_equilibrate(args) -> int:
    cfg = load_config(args.config)
    if cfg.run.mode != "full":
        raise ValueError("equilibrate is defined only for full H1 configurations.")
    model = FullCableModel(cfg)
    eq = solve_static_equilibrium(cfg, model)
    output = Path(args.output or (Path(cfg.run.output_directory) / "static_equilibrium.npz"))
    output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(output, positions=eq.positions, velocities=eq.velocities)
    meta = {
        "converged": eq.converged,
        "force_residual_max_N": eq.force_residual_max,
        "iterations": eq.iterations,
        "metadata": eq.metadata,
        "output": str(output),
    }
    write_json(output.with_suffix(".json"), meta)
    _print(meta)
    return 0


def cmd_simulate(args) -> int:
    cfg = load_config(args.config)
    result = simulate(cfg)
    _print({"status": "success", "run_directory": cfg.run.output_directory, "model": getattr(result, "model_name", "A0")})
    return 0


def cmd_analyze(args) -> int:
    _print(analyze_run(args.run_directory))
    return 0


def cmd_modes(args) -> int:
    report = analyze_linear_modes(args.config, count=args.count)
    if args.output:
        write_json(Path(args.output), report)
    _print(report)
    return 0


def cmd_compare(args) -> int:
    _print(compare_runs(args.run_a, args.run_b))
    return 0


def cmd_compare_experiment(args) -> int:
    report = compare_experiment(
        args.run_directory,
        args.experiment_csv,
        estimate_time_shift=args.estimate_time_shift,
        maximum_time_shift_s=args.maximum_time_shift,
        estimate_translation=args.estimate_translation,
        estimate_planar_rotation=args.estimate_planar_rotation,
        output_directory=args.output_directory,
    )
    _print(report)
    return 0


def cmd_converge(args) -> int:
    _print(run_convergence_study(args.config))
    return 0


def cmd_ablate(args) -> int:
    _print(run_ablation(args.config))
    return 0


def cmd_sweep(args) -> int:
    _print(run_sweep(args.sweep_yaml))
    return 0


def cmd_uncertainty(args) -> int:
    spec_path = Path(args.spec)
    spec = yaml.safe_load(spec_path.read_text(encoding="utf-8"))
    config_path = (spec_path.parent / spec["base_config"]).resolve()
    report = run_uncertainty(
        config_path,
        spec["distributions"],
        samples=args.samples or int(spec.get("samples", 100)),
        workers=args.workers,
    )
    _print(report)
    return 0


def cmd_calibrate_axial(args) -> int:
    frame = pd.read_csv(args.csv)
    required = {args.force_column, args.extension_column}
    missing = required.difference(frame.columns)
    if missing:
        raise ValueError(f"Axial calibration CSV is missing columns: {sorted(missing)}")
    force = frame[args.force_column].to_numpy(dtype=float)
    extension = frame[args.extension_column].to_numpy(dtype=float)
    calibration = fit_axial_stiffness(force, extension, args.rest_length)
    payload = {
        "calibration_type": "independent_axial_loading",
        "source_csv": str(Path(args.csv)),
        "source_csv_sha256": sha256_file(args.csv),
        "force_column": args.force_column,
        "extension_column": args.extension_column,
        **calibration.as_dict(),
        "recommended_config": {
            "young_modulus_note": "The cable model requires E; divide fitted EA by independently measured cross-sectional area.",
            "ea_N": calibration.ea,
            "source": "calibrated_independent",
        },
    }
    if args.table_output:
        curve = build_tabulated_tension_extension(force, extension, args.rest_length)
        table = pd.DataFrame(
            {
                "extension": curve["extension_m"],
                "tension": curve["tension_n"],
            }
        )
        target = Path(args.table_output)
        target.parent.mkdir(parents=True, exist_ok=True)
        table.to_csv(target, index=False)
        payload["tabulated_curve"] = str(target)
        payload["tabulated_calibration_length_m"] = curve["calibration_length_m"]
    if args.output:
        write_json(Path(args.output), payload)
    _print(payload)
    return 0


def cmd_calibrate_damping(args) -> int:
    frame = pd.read_csv(args.csv)
    required = {args.time_column, args.amplitude_column}
    missing = required.difference(frame.columns)
    if missing:
        raise ValueError(f"Damping calibration CSV is missing columns: {sorted(missing)}")
    report = compare_envelope_models(
        frame[args.time_column].to_numpy(dtype=float),
        frame[args.amplitude_column].to_numpy(dtype=float),
    )
    payload = {
        "calibration_type": "independent_modal_envelope_diagnostic",
        "source_csv": str(Path(args.csv)),
        "source_csv_sha256": sha256_file(args.csv),
        "time_column": args.time_column,
        "amplitude_column": args.amplitude_column,
        **report,
    }
    if args.output:
        write_json(Path(args.output), payload)
    _print(payload)
    return 0


def cmd_validate_suite(args) -> int:
    from ypendulum.validation_suite import run_validation_suite

    report = run_validation_suite(fast=args.fast, output_directory=args.output_directory)
    _print(report)
    return 0 if report["passed"] else 2


def cmd_ui(_args) -> int:
    try:
        from streamlit.web import cli as stcli
    except ImportError as exc:
        raise RuntimeError("Streamlit is not installed. Install ypendulum[ui].") from exc
    app_path = Path(__file__).with_name("ui") / "app.py"
    sys.argv = ["streamlit", "run", str(app_path)]
    return int(stcli.main())


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ypendulum", description="YP-FPSim first-principles Y-pendulum simulator")
    parser.add_argument("--version", action="version", version=__version__)
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("validate-config"); p.add_argument("config"); p.set_defaults(func=cmd_validate_config)
    p = sub.add_parser("diagnose")
    p.add_argument("config")
    p.add_argument("--skip-equilibrium", action="store_true")
    p.add_argument("--output")
    p.set_defaults(func=cmd_diagnose)
    p = sub.add_parser("equilibrate"); p.add_argument("config"); p.add_argument("--output"); p.set_defaults(func=cmd_equilibrate)
    p = sub.add_parser("simulate"); p.add_argument("config"); p.set_defaults(func=cmd_simulate)
    p = sub.add_parser("analyze"); p.add_argument("run_directory"); p.set_defaults(func=cmd_analyze)
    p = sub.add_parser("modes"); p.add_argument("config"); p.add_argument("--count", type=int, default=2); p.add_argument("--output"); p.set_defaults(func=cmd_modes)
    p = sub.add_parser("compare"); p.add_argument("run_a"); p.add_argument("run_b"); p.set_defaults(func=cmd_compare)
    p = sub.add_parser("compare-experiment")
    p.add_argument("run_directory")
    p.add_argument("experiment_csv")
    p.add_argument("--estimate-time-shift", action="store_true")
    p.add_argument("--maximum-time-shift", type=float, default=0.0, metavar="SECONDS")
    p.add_argument("--estimate-translation", action="store_true")
    p.add_argument("--estimate-planar-rotation", action="store_true")
    p.add_argument("--output-directory")
    p.set_defaults(func=cmd_compare_experiment)
    p = sub.add_parser("converge"); p.add_argument("config"); p.set_defaults(func=cmd_converge)
    p = sub.add_parser("ablate"); p.add_argument("config"); p.set_defaults(func=cmd_ablate)
    p = sub.add_parser("sweep"); p.add_argument("sweep_yaml"); p.set_defaults(func=cmd_sweep)
    p = sub.add_parser("uncertainty"); p.add_argument("spec"); p.add_argument("--samples", type=int); p.add_argument("--workers", type=int, default=1); p.set_defaults(func=cmd_uncertainty)
    p = sub.add_parser("calibrate-axial")
    p.add_argument("csv")
    p.add_argument("--rest-length", type=float, required=True, metavar="METRES")
    p.add_argument("--force-column", default="force_N")
    p.add_argument("--extension-column", default="extension_m")
    p.add_argument("--table-output")
    p.add_argument("--output")
    p.set_defaults(func=cmd_calibrate_axial)
    p = sub.add_parser("calibrate-damping")
    p.add_argument("csv")
    p.add_argument("--time-column", default="time_s")
    p.add_argument("--amplitude-column", default="amplitude_m")
    p.add_argument("--output")
    p.set_defaults(func=cmd_calibrate_damping)
    p = sub.add_parser("validate-suite"); p.add_argument("--fast", action="store_true"); p.add_argument("--output-directory", default="validation/generated"); p.set_defaults(func=cmd_validate_suite)
    p = sub.add_parser("ui"); p.set_defaults(func=cmd_ui)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except Exception as exc:
        print(json.dumps({"status": "error", "type": type(exc).__name__, "message": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
