"""Frozen experimental-validation manifest contract."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml


_CLAIM_RANK = {"VALIDATED": 0, "PREDICTIVE": 1}


@dataclass(frozen=True)
class ValidationManifestAudit:
    path: Path
    claim_level: str
    frozen: bool
    passed: bool
    calibration_run_count: int
    validation_run_count: int
    metric_count: int
    payload: dict[str, Any]

    def as_dict(self) -> dict[str, Any]:
        return {
            "path": str(self.path),
            "claim_level": self.claim_level,
            "frozen": self.frozen,
            "passed": self.passed,
            "calibration_run_count": self.calibration_run_count,
            "validation_run_count": self.validation_run_count,
            "metric_count": self.metric_count,
        }


def resolve_validation_manifest_path(value: str, *, config_source: Path | None) -> Path:
    path = Path(value).expanduser()
    if not path.is_absolute() and config_source is not None:
        path = config_source.parent / path
    return path.resolve()


def load_validation_manifest(
    value: str,
    *,
    config_source: Path | None = None,
    requested_claim: str | None = None,
) -> ValidationManifestAudit:
    path = resolve_validation_manifest_path(value, config_source=config_source)
    if not path.is_file():
        raise ValueError(f"Validation manifest does not exist: {path}")
    payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Validation manifest root must be a mapping.")
    required = {
        "schema_version",
        "frozen",
        "passed",
        "claim_level",
        "frozen_at_utc",
        "model_definition_hash_sha256",
        "calibration_runs",
        "validation_runs",
        "metrics",
    }
    missing = sorted(required.difference(payload))
    if missing:
        raise ValueError(f"Validation manifest is missing required fields: {missing}")
    if str(payload["schema_version"]) != "1.0":
        raise ValueError("Unsupported validation manifest schema_version.")
    claim = str(payload["claim_level"])
    if claim not in _CLAIM_RANK:
        raise ValueError("Validation manifest claim_level must be VALIDATED or PREDICTIVE.")
    if payload["frozen"] is not True:
        raise ValueError("Validation manifest must explicitly set frozen: true.")
    if payload["passed"] is not True:
        raise ValueError("Validation manifest does not record a passed validation campaign.")
    for name in ("calibration_runs", "validation_runs"):
        if not isinstance(payload[name], list):
            raise ValueError(f"Validation manifest {name} must be a list.")
    if not payload["validation_runs"]:
        raise ValueError("Validation manifest must contain at least one sealed validation run.")
    if not isinstance(payload["metrics"], dict) or not payload["metrics"]:
        raise ValueError("Validation manifest must contain quantitative metrics.")
    digest = str(payload["model_definition_hash_sha256"])
    if len(digest) != 64 or any(ch not in "0123456789abcdefABCDEF" for ch in digest):
        raise ValueError("model_definition_hash_sha256 must be a 64-character hexadecimal SHA-256.")
    if requested_claim in _CLAIM_RANK and _CLAIM_RANK[claim] < _CLAIM_RANK[requested_claim]:
        raise ValueError(
            f"Manifest supports {claim}, which is below requested {requested_claim}."
        )
    if requested_claim == "PREDICTIVE":
        pressure = payload.get("predictive_scope")
        if not isinstance(pressure, dict) or not pressure.get("unseen_conditions_passed", False):
            raise ValueError(
                "PREDICTIVE claim requires predictive_scope.unseen_conditions_passed: true."
            )
    return ValidationManifestAudit(
        path=path,
        claim_level=claim,
        frozen=True,
        passed=True,
        calibration_run_count=len(payload["calibration_runs"]),
        validation_run_count=len(payload["validation_runs"]),
        metric_count=len(payload["metrics"]),
        payload=payload,
    )
