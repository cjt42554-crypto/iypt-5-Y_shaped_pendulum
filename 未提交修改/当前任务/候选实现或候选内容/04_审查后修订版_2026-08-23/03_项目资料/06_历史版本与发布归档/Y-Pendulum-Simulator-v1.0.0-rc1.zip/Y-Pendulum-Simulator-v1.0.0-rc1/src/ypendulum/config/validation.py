"""Configuration loading, inheritance and physical validation."""

from __future__ import annotations

import copy
import math
from pathlib import Path
from typing import Any

import numpy as np
import yaml

from .manifest import load_validation_manifest
from .models import SimulationConfig
from .units import as_vector3, source_of, to_si


class ConfigurationError(ValueError):
    """A physically invalid or incomplete simulation configuration."""


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    out = copy.deepcopy(base)
    for key, value in override.items():
        if key == "inherit":
            continue
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _deep_merge(out[key], value)
        else:
            out[key] = copy.deepcopy(value)
    return out


def _resolve_cable_inheritance(raw: dict[str, Any]) -> dict[str, Any]:
    data = copy.deepcopy(raw)
    cables = data.get("cables", {})
    resolved: dict[str, Any] = {}
    visiting: set[str] = set()

    def resolve(name: str) -> dict[str, Any]:
        if name in resolved:
            return resolved[name]
        if name in visiting:
            raise ConfigurationError(f"Circular cable inheritance involving {name!r}.")
        if name not in cables:
            raise ConfigurationError(f"Unknown inherited cable {name!r}.")
        visiting.add(name)
        item = copy.deepcopy(cables[name])
        parent = item.get("inherit")
        if parent:
            item = _deep_merge(resolve(str(parent)), item)
        visiting.remove(name)
        resolved[name] = item
        return item

    for required in ("upper_A", "upper_B", "lower"):
        resolve(required)
    data["cables"] = resolved
    return data


def load_config(path_or_mapping: str | Path | dict[str, Any]) -> SimulationConfig:
    if isinstance(path_or_mapping, (str, Path)):
        path = Path(path_or_mapping).expanduser().resolve()
        with path.open("r", encoding="utf-8") as fh:
            raw = yaml.safe_load(fh)
        if not isinstance(raw, dict):
            raise ConfigurationError("Configuration root must be a mapping.")
        cfg = SimulationConfig.model_validate(_resolve_cable_inheritance(raw))
        cfg.source_path = path
    else:
        cfg = SimulationConfig.model_validate(_resolve_cable_inheritance(path_or_mapping))
    validate_physical_config(cfg)
    return cfg


def validate_physical_config(cfg: SimulationConfig) -> None:
    A = as_vector3(cfg.supports.A.position, default_unit="m")
    B = as_vector3(cfg.supports.B.position, default_unit="m")
    d = float(np.linalg.norm(B - A))
    if not np.isfinite(d) or d <= 0:
        raise ConfigurationError("The two support points must be distinct finite positions.")

    lengths = [
        float(to_si(cfg.cables.upper_A.rest_length, default_unit="m")),
        float(to_si(cfg.cables.upper_B.rest_length, default_unit="m")),
        float(to_si(cfg.cables.lower.rest_length, default_unit="m")),
    ]
    if min(lengths) <= 0:
        raise ConfigurationError("All cable rest lengths must be positive.")
    if not abs(lengths[0] - lengths[1]) < d < lengths[0] + lengths[1]:
        # Elasticity may rescue a slightly infeasible rest geometry, but a gross violation is not a
        # meaningful default start.  Allow up to 2% tensile accommodation.
        if not abs(lengths[0] - lengths[1]) < d < 1.02 * (lengths[0] + lengths[1]):
            raise ConfigurationError(
                "Upper-cable rest lengths and support spacing cannot form a viable fixed-knot Y geometry."
            )

    positive_fields = {
        "junction.mass": to_si(cfg.junction.mass, default_unit="kg"),
        "bob.mass": to_si(cfg.bob.mass, default_unit="kg"),
        "bob.radius": to_si(cfg.bob.radius, default_unit="m"),
    }
    for name, val in positive_fields.items():
        if float(val) <= 0:
            raise ConfigurationError(f"{name} must be strictly positive.")

    for name, cable in (
        ("upper_A", cfg.cables.upper_A),
        ("upper_B", cfg.cables.upper_B),
        ("lower", cfg.cables.lower),
    ):
        vals = {
            "diameter": to_si(cable.diameter, default_unit="m"),
            "density": to_si(cable.density, default_unit="kg/m^3"),
            "young_modulus": to_si(cable.young_modulus, default_unit="Pa"),
        }
        for field, val in vals.items():
            if float(val) <= 0:
                raise ConfigurationError(f"cables.{name}.{field} must be positive.")
        if float(to_si(cable.axial_viscosity, default_unit="Pa*s")) < 0:
            raise ConfigurationError(f"cables.{name}.axial_viscosity cannot be negative.")
        if cable.material_model == "tabulated_tension_extension":
            calibration_length = (
                cable.rest_length
                if cable.table_calibration_length is None
                else cable.table_calibration_length
            )
            if float(to_si(calibration_length, default_unit="m")) <= 0.0:
                raise ConfigurationError(
                    f"cables.{name}.table_calibration_length must be positive."
                )

    if cfg.run.mode == "full":
        minimum = (12, 12, 20) if cfg.solver.profile == "quick" else (20, 20, 30)
        actual = (
            cfg.cables.upper_A.elements,
            cfg.cables.upper_B.elements,
            cfg.cables.lower.elements,
        )
        if any(value < required for value, required in zip(actual, minimum)):
            if not cfg.solver.allow_subminimum_mesh:
                raise ConfigurationError(
                    "H1 mesh is below the frozen minimum "
                    f"{minimum[0]}/{minimum[1]}/{minimum[2]} for profile="
                    f"{cfg.solver.profile}; got {actual[0]}/{actual[1]}/{actual[2]}. "
                    "Use a compliant mesh for scientific runs.  "
                    "Set solver.allow_subminimum_mesh=true only for explicit smoke/unit tests."
                )
            if cfg.run.claim_level not in {"DERIVED", "VERIFIED"}:
                raise ConfigurationError(
                    "A subminimum mesh override cannot be used for CALIBRATED, VALIDATED, "
                    "PREDICTIVE or OUT_OF_SCOPE claims."
                )

    newmark_force_tol = float(
        to_si(cfg.solver.newmark_force_tolerance, default_unit="N")
    )
    if newmark_force_tol <= 0:
        raise ConfigurationError("solver.newmark_force_tolerance must be positive.")

    t_end = float(to_si(cfg.solver.t_end, default_unit="s"))
    output_dt = float(to_si(cfg.solver.output_dt, default_unit="s"))
    if t_end <= 0 or output_dt <= 0 or output_dt > t_end:
        raise ConfigurationError("Require 0 < output_dt <= t_end.")

    p, q = cfg.analysis.target_ratio
    if math.gcd(p, q) != 1:
        raise ConfigurationError("target_ratio must contain coprime integers.")

    if cfg.run.claim_level in {"VALIDATED", "PREDICTIVE"}:
        if not cfg.run.validation_manifest:
            raise ConfigurationError(
                f"claim_level={cfg.run.claim_level} requires a validation_manifest."
            )
        try:
            load_validation_manifest(
                cfg.run.validation_manifest,
                config_source=cfg.source_path,
                requested_claim=cfg.run.claim_level,
            )
        except ValueError as exc:
            raise ConfigurationError(f"Invalid validation_manifest: {exc}") from exc
    if cfg.run.claim_level == "PREDICTIVE":
        suspect: list[str] = []
        physical_values = [
            ("junction.mass", cfg.junction.mass),
            ("bob.mass", cfg.bob.mass),
            ("bob.radius", cfg.bob.radius),
            ("upper_A.E", cfg.cables.upper_A.young_modulus),
            ("upper_B.E", cfg.cables.upper_B.young_modulus),
            ("lower.E", cfg.cables.lower.young_modulus),
        ]
        for name, value in physical_values:
            src = source_of(value)
            if src in {None, "assumed", "fitted_target"}:
                suspect.append(name)
        if suspect:
            raise ConfigurationError(
                "PREDICTIVE claim rejected because parameters lack independent provenance: "
                + ", ".join(suspect)
            )


def resolved_config_dict(cfg: SimulationConfig) -> dict[str, Any]:
    """Return a JSON/YAML-safe SI representation used for run provenance."""

    def q(v: Any, unit: str) -> Any:
        x = to_si(v, default_unit=unit)
        return np.asarray(x).tolist() if isinstance(x, np.ndarray) else float(x)

    out = cfg.model_dump(mode="python", exclude={"source_path"})
    out["environment"]["gravity"] = q(cfg.environment.gravity, "m/s^2")
    out["environment"]["air_density"] = q(cfg.environment.air_density, "kg/m^3")
    out["environment"]["air_velocity"] = q(cfg.environment.air_velocity, "m/s")
    for key, support in (("A", cfg.supports.A), ("B", cfg.supports.B)):
        out["supports"][key]["position"] = q(support.position, "m")
        if support.motion:
            out["supports"][key]["motion"]["amplitude"] = q(support.motion.amplitude, "m")
            out["supports"][key]["motion"]["frequency"] = q(support.motion.frequency, "Hz")
            out["supports"][key]["motion"]["phase"] = q(support.motion.phase, "rad")
    out["junction"]["mass"] = q(cfg.junction.mass, "kg")
    out["junction"]["drag_linear"] = q(cfg.junction.drag_linear, "N*s/m")
    out["bob"]["mass"] = q(cfg.bob.mass, "kg")
    out["bob"]["radius"] = q(cfg.bob.radius, "m")
    out["bob"]["drag"]["cd"] = q(cfg.bob.drag.cd, "dimensionless")
    out["bob"]["drag"]["linear_coefficient"] = q(
        cfg.bob.drag.linear_coefficient, "N*s/m"
    )
    for name in ("upper_A", "upper_B", "lower"):
        cable = getattr(cfg.cables, name)
        target = out["cables"][name]
        target["rest_length"] = q(cable.rest_length, "m")
        target["diameter"] = q(cable.diameter, "m")
        target["density"] = q(cable.density, "kg/m^3")
        target["young_modulus"] = q(cable.young_modulus, "Pa")
        target["axial_viscosity"] = q(cable.axial_viscosity, "Pa*s")
        if cable.table_calibration_length is not None:
            target["table_calibration_length"] = q(
                cable.table_calibration_length, "m"
            )
    out["initial_condition"]["phi"] = q(cfg.initial_condition.phi, "rad")
    out["initial_condition"]["theta"] = q(cfg.initial_condition.theta, "rad")
    out["initial_condition"]["phi_dot"] = q(cfg.initial_condition.phi_dot, "rad/s")
    out["initial_condition"]["theta_dot"] = q(cfg.initial_condition.theta_dot, "rad/s")
    out["initial_condition"]["bob_velocity"] = q(cfg.initial_condition.bob_velocity, "m/s")
    if cfg.initial_condition.bob_position is not None:
        out["initial_condition"]["bob_position"] = q(
            cfg.initial_condition.bob_position, "m"
        )
    out["solver"]["t_end"] = q(cfg.solver.t_end, "s")
    out["solver"]["output_dt"] = q(cfg.solver.output_dt, "s")
    if cfg.solver.max_step != "auto":
        out["solver"]["max_step"] = q(cfg.solver.max_step, "s")
    out["solver"]["static"]["force_tolerance"] = q(
        cfg.solver.static.force_tolerance, "N"
    )
    out["solver"]["newmark_force_tolerance"] = q(
        cfg.solver.newmark_force_tolerance, "N"
    )
    out["analysis"]["phase_tolerance"] = q(cfg.analysis.phase_tolerance, "rad")
    return out
