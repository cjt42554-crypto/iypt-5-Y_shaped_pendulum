"""HDF5 run format with units and descriptions."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import h5py
import numpy as np

from ypendulum.models.state import SimulationResult


def _dataset(
    h5: h5py.File,
    name: str,
    data: Any,
    *,
    unit: str,
    description: str,
    compression: bool = True,
):
    arr = np.asarray(data)
    kwargs = {"compression": "gzip", "shuffle": True} if compression and arr.size > 32 else {}
    ds = h5.create_dataset(name, data=arr, **kwargs)
    ds.attrs["unit"] = unit
    ds.attrs["description"] = description
    return ds


def write_h1_result(
    path: str | Path,
    result: SimulationResult,
    model,
    observer_pixels=None,
    observer_time=None,
) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with h5py.File(target, "w") as h5:
        h5.attrs["format"] = "YP-FPSim H1 result"
        h5.attrs["format_version"] = "1.0"
        h5.attrs["model"] = result.model_name
        h5.attrs["claim_level"] = result.claim_level
        _dataset(h5, "/time", result.time, unit="s", description="Absolute simulation time")
        _dataset(
            h5,
            "/state/positions",
            result.positions,
            unit="m",
            description="All mesh-node world positions; shape (time,node,xyz)",
        )
        _dataset(
            h5,
            "/state/velocities",
            result.velocities,
            unit="m/s",
            description="All mesh-node world velocities",
        )
        string_type = h5py.string_dtype(encoding="utf-8")
        labels = h5.create_dataset(
            "/mesh/node_labels",
            data=np.asarray(model.topology.node_labels, dtype=object),
            dtype=string_type,
        )
        labels.attrs["unit"] = "1"
        labels.attrs["description"] = "Stable mesh-node labels"
        _dataset(
            h5,
            "/mesh/elements/node_i",
            model.topology.elements.node_i,
            unit="1",
            description="Element first-node indices",
        )
        _dataset(
            h5,
            "/mesh/elements/node_j",
            model.topology.elements.node_j,
            unit="1",
            description="Element second-node indices",
        )
        _dataset(
            h5,
            "/mesh/elements/rest_length",
            model.topology.elements.rest_length,
            unit="m",
            description="Element natural lengths",
        )
        j = model.topology.junction_node
        b = model.topology.bob_node
        _dataset(h5, "/bodies/junction/position", result.positions[:, j], unit="m", description="Junction position")
        _dataset(h5, "/bodies/junction/velocity", result.velocities[:, j], unit="m/s", description="Junction velocity")
        _dataset(h5, "/bodies/bob/position", result.positions[:, b], unit="m", description="Bob centre-of-mass position")
        _dataset(h5, "/bodies/bob/velocity", result.velocities[:, b], unit="m/s", description="Bob centre-of-mass velocity")
        for name, sl in model.topology.cable_slices.items():
            path_nodes = model.topology.cable_node_paths[name]
            _dataset(
                h5,
                f"/cables/{name}/nodes/position",
                result.positions[:, path_nodes],
                unit="m",
                description=f"{name} cable node positions",
            )
            _dataset(
                h5,
                f"/cables/{name}/nodes/velocity",
                result.velocities[:, path_nodes],
                unit="m/s",
                description=f"{name} cable node velocities",
            )
            _dataset(
                h5,
                f"/cables/{name}/elements/tension",
                result.tension[:, sl],
                unit="N",
                description=f"{name} element axial tension; never negative",
            )
            _dataset(
                h5,
                f"/cables/{name}/elements/stretch",
                result.stretch[:, sl],
                unit="m",
                description=f"{name} current length minus rest length",
            )
            _dataset(
                h5,
                f"/cables/{name}/elements/active",
                result.active[:, sl].astype(np.uint8),
                unit="1",
                description=f"{name} unilateral tensile active flag",
            )
        _dataset(h5, "/reactions/support_A", result.reactions["support_A"], unit="N", description="Reaction exerted by support A on the system")
        _dataset(h5, "/reactions/support_B", result.reactions["support_B"], unit="N", description="Reaction exerted by support B on the system")
        energy_units = {
            "kinetic": "J",
            "gravitational": "J",
            "elastic": "J",
            "mechanical": "J",
            "material_dissipation_rate": "W",
            "aero_relative_dissipation_rate": "W",
            "aero_work_rate": "W",
            "support_work_rate": "W",
            "dissipation_material": "J",
            "dissipation_aero_relative": "J",
            "aero_work": "J",
            "support_work": "J",
            "balance_residual": "1",
        }
        for key, values in result.energy.items():
            _dataset(
                h5,
                f"/energy/{key}",
                values,
                unit=energy_units.get(key, "1"),
                description=key.replace("_", " "),
            )
        if "dissipation_aero_relative" in result.energy:
            _dataset(
                h5,
                "/energy/dissipation_aero",
                result.energy["dissipation_aero_relative"],
                unit="J",
                description="Cumulative aerodynamic dissipation relative to the air",
            )
        if observer_pixels is not None:
            _dataset(h5, "/observer/pixels", observer_pixels, unit="pixel", description="Predicted camera pixels")
            if observer_time is None:
                raise ValueError("observer_time is required whenever observer_pixels are written.")
            _dataset(
                h5,
                "/observer/time",
                observer_time,
                unit="s",
                description="Observer sample mid-exposure times",
            )


def read_h1_result(path: str | Path) -> dict[str, Any]:
    out: dict[str, Any] = {}
    with h5py.File(path, "r") as h5:
        out["time"] = np.asarray(h5["/time"])
        out["positions"] = np.asarray(h5["/state/positions"])
        out["velocities"] = np.asarray(h5["/state/velocities"])
        out["bob_position"] = np.asarray(h5["/bodies/bob/position"])
        out["junction_position"] = np.asarray(h5["/bodies/junction/position"])
        out["energy_balance_residual"] = np.asarray(h5["/energy/balance_residual"])
        out["model"] = h5.attrs.get("model", "H1")
        out["claim_level"] = h5.attrs.get("claim_level", "VERIFIED")
    return out
