"""Local Streamlit interface.

The UI deliberately delegates every physical calculation to the public core
API.  It is an optional presentation layer, not an independent simulator.
"""

from __future__ import annotations

import io
import tempfile
import zipfile
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import streamlit as st
import yaml

from ypendulum import load_config, simulate
from ypendulum.analysis import (
    assess_result_validity,
    automatic_scale_diagnostics,
    dominant_frequency_estimates,
)
from ypendulum.config import resolved_config_dict
from ypendulum.models.full_cable import FullCableModel
from ypendulum.models.state import SimulationResult, TorusResult
from ypendulum.solvers.static import solve_static_equilibrium


_FALLBACK_CONFIG = """schema_version: '1.0'
run:
  name: ui_preview
  mode: full
  seed: 20260818
  output_directory: runs/ui_preview
  claim_level: VERIFIED
environment:
  gravity: {value: [0, 0, -9.80665], unit: m/s^2}
  air_density: {value: 1.20, unit: kg/m^3}
  air_velocity: {value: [0, 0, 0], unit: m/s}
supports:
  A: {type: fixed, position: {value: [-0.15, 0, 0], unit: m}}
  B: {type: fixed, position: {value: [0.15, 0, 0], unit: m}}
junction:
  mass: {value: 0.002, unit: kg, source: measured}
bob:
  mass: {value: 0.200, unit: kg, source: measured}
  radius: {value: 0.010, unit: m, source: measured}
  drag: {enabled: false}
  buoyancy: false
cables:
  upper_A:
    rest_length: {value: 0.403887, unit: m, source: measured}
    diameter: {value: 0.001, unit: m, source: measured}
    density: {value: 1000, unit: kg/m^3, source: datasheet}
    young_modulus: {value: 2.0e6, unit: Pa, source: calibrated_independent}
    axial_viscosity: {value: 500, unit: Pa*s, source: calibrated_independent}
    elements: 12
  upper_B: {inherit: upper_A}
  lower:
    rest_length: {value: 0.300, unit: m, source: measured}
    diameter: {value: 0.001, unit: m, source: measured}
    density: {value: 1000, unit: kg/m^3, source: datasheet}
    young_modulus: {value: 2.0e6, unit: Pa, source: calibrated_independent}
    axial_viscosity: {value: 500, unit: Pa*s, source: calibrated_independent}
    elements: 20
initial_condition:
  type: reduced_angles_release
  phi: {value: 2.0, unit: degree}
  theta: {value: 1.0, unit: degree}
solver:
  profile: quick
  t_end: {value: 0.2, unit: s}
  output_dt: {value: 0.002, unit: s}
  mass_matrix: lumped
  method: Radau
analysis:
  target_ratio: [3, 2]
observer: {type: orthographic_xy}
"""


def _default_config_text() -> str:
    project_example = (
        Path(__file__).resolve().parents[3]
        / "configs"
        / "examples"
        / "full_quick_3to2.yaml"
    )
    return project_example.read_text(encoding="utf-8") if project_example.exists() else _FALLBACK_CONFIG


def _zip_directory(directory: Path) -> bytes:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(directory.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(directory))
    return buffer.getvalue()


def _plot_static(model: FullCableModel, positions: np.ndarray):
    fig = plt.figure(figsize=(6, 5))
    ax = fig.add_subplot(111, projection="3d")
    for name, path in model.topology.cable_node_paths.items():
        xyz = positions[path]
        ax.plot(xyz[:, 0], xyz[:, 1], xyz[:, 2], marker="o", markersize=2, label=name)
    ax.set_xlabel("x [m]")
    ax.set_ylabel("y [m]")
    ax.set_zlabel("z [m]")
    ax.legend()
    fig.tight_layout()
    return fig


def _show_result(cfg, result, model: FullCableModel | None) -> None:
    if isinstance(result, SimulationResult):
        bob = result.positions[:, -1]
        st.subheader("轨迹与状态")
        left, right = st.columns(2)
        with left:
            fig, ax = plt.subplots()
            ax.plot(bob[:, 0], bob[:, 1])
            ax.set_aspect("equal", adjustable="box")
            ax.set_xlabel("x [m]")
            ax.set_ylabel("y [m]")
            fig.tight_layout()
            st.pyplot(fig)
            plt.close(fig)
        with right:
            fig = plt.figure()
            ax = fig.add_subplot(111, projection="3d")
            ax.plot(bob[:, 0], bob[:, 1], bob[:, 2])
            ax.set_xlabel("x [m]")
            ax.set_ylabel("y [m]")
            ax.set_zlabel("z [m]")
            fig.tight_layout()
            st.pyplot(fig)
            plt.close(fig)

        assert model is not None
        st.subheader("张力、伸长和能量")
        fig, ax = plt.subplots()
        for name, cable_slice in model.topology.cable_slices.items():
            ax.plot(
                result.time,
                np.max(result.tension[:, cable_slice], axis=1),
                label=name,
            )
        ax.set_xlabel("time [s]")
        ax.set_ylabel("maximum element tension [N]")
        ax.legend()
        fig.tight_layout()
        st.pyplot(fig)
        plt.close(fig)

        fig, ax = plt.subplots()
        ax.plot(result.time, result.energy["balance_residual"], label="balance residual")
        ax.set_xlabel("time [s]")
        ax.set_ylabel("dimensionless")
        ax.legend()
        fig.tight_layout()
        st.pyplot(fig)
        plt.close(fig)

        st.subheader("频率可靠性")
        if result.time.size >= 12:
            signals = bob[:, :2] - np.mean(bob[:, :2], axis=0)
            estimates = dominant_frequency_estimates(
                result.time, signals, minimum_cycles=3.0
            )
            st.json(
                {
                    "x": {
                        "candidate_hz": estimates[0].frequency_hz,
                        "reliable": estimates[0].reliable,
                        "observed_cycles": estimates[0].observed_cycles,
                        "fit_r2": estimates[0].fit_r2,
                        "reason": estimates[0].reason,
                    },
                    "y": {
                        "candidate_hz": estimates[1].frequency_hz,
                        "reliable": estimates[1].reliable,
                        "observed_cycles": estimates[1].observed_cycles,
                        "fit_r2": estimates[1].fit_r2,
                        "reason": estimates[1].reason,
                    },
                }
            )
            if not all(item.reliable for item in estimates):
                st.warning("记录不足以支持稳定双主频声明；候选值只用于诊断。")
        else:
            st.info("记录样本不足，不进行主频声明。")

        st.subheader("事件时间线")
        if result.events:
            st.dataframe(result.events, use_container_width=True)
        else:
            st.info("当前输出采样下未识别到松弛/重新受拉事件。")
        st.subheader("求解与结果有效性")
        preflight = automatic_scale_diagnostics(
            cfg, model, loaded_positions=result.positions[0]
        )
        validity = assess_result_validity(cfg, model, result, preflight=preflight)
        st.json(
            {
                "solver_and_model": result.diagnostics,
                "preflight": preflight,
                "result_validity": validity,
            }
        )
    elif isinstance(result, TorusResult):
        fig, ax = plt.subplots()
        ax.plot(result.position[:, 0], result.position[:, 1])
        ax.set_aspect("equal", adjustable="box")
        ax.set_xlabel("x [m]")
        ax.set_ylabel("y [m]")
        st.pyplot(fig)
        plt.close(fig)
        st.json({"event": result.event})
    else:
        st.json(result.__dict__)


st.set_page_config(page_title="YP-FPSim", layout="wide")
st.title("YP-FPSim — 第一性原理 Y-Pendulum 仿真器")
st.caption("本地界面调用与 CLI 完全相同的核心物理 API；不会在前端复制方程。")

if "config_text" not in st.session_state:
    st.session_state.config_text = _default_config_text()
if "run_archive" not in st.session_state:
    st.session_state.run_archive = None

uploaded = st.file_uploader("导入 YAML 配置", type=["yaml", "yml"])
if uploaded is not None:
    st.session_state.config_text = uploaded.getvalue().decode("utf-8")

text = st.text_area("配置", value=st.session_state.config_text, height=560)
st.session_state.config_text = text
st.download_button(
    "导出当前 YAML",
    data=text.encode("utf-8"),
    file_name="ypendulum_config.yaml",
    mime="text/yaml",
)

cfg = None
model = None
try:
    raw = yaml.safe_load(text)
    cfg = load_config(raw)
    st.success(f"配置有效：{cfg.run.name} / {cfg.run.mode} / {cfg.run.claim_level}")
    st.expander("解析后的 SI 配置").json(resolved_config_dict(cfg))
    if cfg.run.mode == "full":
        model = FullCableModel(cfg)
        preview = solve_static_equilibrium(cfg, model)
        st.subheader("自动量级诊断")
        st.json(automatic_scale_diagnostics(cfg, model, equilibrium=preview))
        st.subheader("静态几何预览")
        fig = _plot_static(model, preview.positions)
        st.pyplot(fig)
        plt.close(fig)
except Exception as exc:  # visible configuration feedback, not silent recovery
    st.error(f"配置或静力求解失败：{type(exc).__name__}: {exc}")
    cfg = None
    model = None

compare_a1 = st.checkbox("全模型运行后同时计算 A1 环面基准", value=False)
if st.button("运行仿真", type="primary", disabled=cfg is None):
    assert cfg is not None
    directory = Path(tempfile.mkdtemp(prefix="ypendulum_ui_"))
    cfg.run.output_directory = str(directory)
    with st.status("正在求解", expanded=True) as status:
        st.write("构造模型与初态")
        result = simulate(cfg)
        st.write("生成分析、事件与可下载结果")
        if compare_a1 and cfg.run.mode == "full":
            torus_cfg = cfg.model_copy(deep=True)
            torus_cfg.run.mode = "torus"
            torus_cfg.run.output_directory = str(directory / "A1_reference")
            try:
                torus_result = simulate(torus_cfg)
                st.write(
                    {
                        "A1_final_position_m": torus_result.position[-1].tolist(),
                        "H1_final_position_m": result.positions[-1, -1].tolist(),
                    }
                )
            except Exception as exc:
                st.warning(f"A1 对照超出正张力范围或失败：{exc}")
        status.update(label="仿真完成", state="complete")
    st.session_state.run_archive = _zip_directory(directory)
    st.session_state.run_archive_name = f"{cfg.run.name}_run.zip"
    _show_result(cfg, result, model)

if st.session_state.run_archive is not None:
    st.download_button(
        "下载完整运行目录",
        data=st.session_state.run_archive,
        file_name=st.session_state.run_archive_name,
        mime="application/zip",
    )

st.divider()
st.caption(
    "界面展示的是数值求解结果。没有独立校准和封存实验验证时，"
    "不得把曲线外观相似称为 VALIDATED 或 PREDICTIVE。"
)
