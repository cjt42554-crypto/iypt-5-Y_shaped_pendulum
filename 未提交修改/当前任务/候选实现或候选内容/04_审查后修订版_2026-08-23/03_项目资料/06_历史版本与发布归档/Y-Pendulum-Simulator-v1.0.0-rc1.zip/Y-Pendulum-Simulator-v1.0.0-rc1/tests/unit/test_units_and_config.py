import copy
import numpy as np
import pytest
from ypendulum.config import ConfigurationError, load_config, resolved_config_dict
from ypendulum.config.units import UnitError, as_vector3, to_si

def test_unit_conversion_and_dimension_check():
    assert to_si({"value":12.0,"unit":"cm"},default_unit="m")==pytest.approx(0.12)
    assert to_si({"value":180.0,"unit":"degree"},default_unit="rad")==pytest.approx(np.pi)
    with pytest.raises(UnitError): to_si({"value":1.0,"unit":"kg"},default_unit="m")

def test_vector_shape_check():
    assert np.allclose(as_vector3({"value":[1,2,3],"unit":"cm"},default_unit="m"),[.01,.02,.03])
    with pytest.raises(UnitError): as_vector3({"value":[1,2],"unit":"m"},default_unit="m")

def test_cable_inheritance_and_resolved_newmark(config_dict):
    cfg=load_config(config_dict); assert cfg.cables.upper_B.rest_length==cfg.cables.upper_A.rest_length
    assert resolved_config_dict(cfg)["solver"]["newmark_force_tolerance"]==pytest.approx(1e-7)

def test_invalid_mesh_and_newmark_parameters(config_dict):
    bad=copy.deepcopy(config_dict); bad["solver"]["allow_subminimum_mesh"]=False
    with pytest.raises(ConfigurationError): load_config(bad)
    bad=copy.deepcopy(config_dict); bad["solver"]["newmark_beta"]=0.1; bad["solver"]["newmark_gamma"]=0.5
    with pytest.raises(ValueError): load_config(bad)
