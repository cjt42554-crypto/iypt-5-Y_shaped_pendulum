from __future__ import annotations

import copy
from pathlib import Path

import pytest
import yaml

from ypendulum.config import ConfigurationError, load_config, load_validation_manifest


def _manifest(claim: str = "VALIDATED") -> dict:
    return {
        "schema_version": "1.0",
        "frozen": True,
        "passed": True,
        "claim_level": claim,
        "frozen_at_utc": "2026-08-18T00:00:00Z",
        "model_definition_hash_sha256": "a" * 64,
        "calibration_runs": [{"run_id": "c1", "data_sha256": "b" * 64}],
        "validation_runs": [{"run_id": "v1", "data_sha256": "c" * 64}],
        "metrics": {"frequency_ratio_relative_error": {"value": 0.0005, "passed": True}},
        "predictive_scope": {"unseen_conditions_passed": claim == "PREDICTIVE"},
    }


def test_manifest_contract_and_predictive_scope(tmp_path: Path) -> None:
    path = tmp_path / "manifest.yaml"
    path.write_text(yaml.safe_dump(_manifest("PREDICTIVE")), encoding="utf-8")
    audit = load_validation_manifest(str(path), requested_claim="PREDICTIVE")
    assert audit.passed and audit.validation_run_count == 1

    bad = _manifest("PREDICTIVE")
    bad["predictive_scope"]["unseen_conditions_passed"] = False
    path.write_text(yaml.safe_dump(bad), encoding="utf-8")
    with pytest.raises(ValueError):
        load_validation_manifest(str(path), requested_claim="PREDICTIVE")


def test_claim_config_rejects_nonexistent_or_failed_manifest(config_dict, tmp_path: Path) -> None:
    raw = copy.deepcopy(config_dict)
    raw["run"]["claim_level"] = "VALIDATED"
    raw["run"]["validation_manifest"] = str(tmp_path / "missing.yaml")
    with pytest.raises(ConfigurationError):
        load_config(raw)

    path = tmp_path / "failed.yaml"
    failed = _manifest("VALIDATED")
    failed["passed"] = False
    path.write_text(yaml.safe_dump(failed), encoding="utf-8")
    raw["run"]["validation_manifest"] = str(path)
    with pytest.raises(ConfigurationError):
        load_config(raw)
